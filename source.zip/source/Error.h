/*
   Modulo             : Error.h
                        Tabla Mensaje de Errores
   Autor              : Jose Secundino Alvites Rodas
   Fecha Creacion     : Miercoles 30 de Marzo del 2005
   Fecha Actualizacion: Sabado 02 de Abril del 2005
   Pais               : Per�
   Asesor             : Ing. Eduardo Alonso P�rez
*/
#define MAX_MENSAJE                       250

#define ERROR_TIPO_INCORRECTO             0
#define ERROR_RANGO_INCORRECTO            1
#define ERROR_VARIABLE_NO_DECLARADA       2
#define ERROR_TIPO_NO_DECLARADO           3
#define ERROR_VARIABLE_YA_DECLARADA       4
#define ERROR_INDICE_INCORRECTO           5
#define ERROR_BUCLE_MAL_ANIDADO           6
#define ERROR_ESPERABA_ENTONCES           7
#define ERROR_ESPERABA_FINSI              8
#define ERROR_FUNCION_NO_DEFINIDA         9
#define ERROR_ESPERABA_FIN_INSTRUCCION    10
#define ERROR_ESPERABA_EXPRESION          11
#define ERROR_ESPERABA_HASTA              12
#define ERROR_ESPERABA_FIN_DESDE          13
#define ERROR_VARIABLE_ESTA_EN_USO        14
#define ERROR_MIENTRAS_SIN_FIN_MIENTRAS   15
#define ERROR_REPETIR_SIN_HASTAQUE        16
#define ERROR_SEGUNSEA_SIN_FINSEGUNSEA    17
#define ERROR_DIVISION_ENTRE_CERO         18
#define ERROR_INDICE_FUERA_INTERVALO      19
#define ERROR_NO_COINCIDE_TIPO            20
#define ERROR_ARGUMENTO_NO_ES_OPCIONAL    21
#define ERROR_GENERACION_CODIGO_INTERMEDIO    22
#define ERROR_DESBORDAMIENTO               23
#define ERROR_ESPERABA_PARENTESIS          24//NO MUY CLARO
#define ERROR_DE_SINTAXIS                  25
#define ERROR_ESPERABA_UNA_MATRIZ          26
#define ERROR_ESPERABA_UNA_CONSTANTE       27
#define ERROR_INTERVALO_NO_TIENE_VALORES   28
#define ERROR_ESPERABA_CERRAR_PARENTESIS   29
#define ERROR_ESPERABA_IDENTIFICADOR       30
#define ERROR_NUMERO_ARGUMENTOS_ERRONEO    31
#define ERROR_DETECTADO_NOMBRE_AMBIGUO     32
#define ERROR_DECLARACION_DUPLICADA        33
#define ERROR_EXPRESION_NO_VALIDA          34
#define ERROR_ESPERABA_VARIABLE            35
#define ERROR_CARACTER_NO_VALIDO           36
//Caso de calcular raiz cuadrada con numeros negativos
#define ERROR_ARGUMENTO_NO_VALIDO          37 //En tiempo de ejecucion
#define ERROR_ESPERABA_IGUAL               38
//.a
#define ERROR_REFERENCIA_NO_VALIDA         39
#define ERROR_DECLARACION_DUPLICADA_ALCANCE_ACTUAL 40
#define ERROR_ESPERABA_NOMBRE_TIPO         41
#define ERROR_TIPO_ARGUMENTO_NO_COINCIDE   42
//Se da cuando se definen funciones, estructuras condionales fuera del ambito local
#define ERROR_PROCEDIMIENTO_EXTERNO_NO_VALIDO   43

char *MensajeErrores[]=
{
     "Tipo incorrecto",
     "Rango incorrecto",
     "Variable no declarada",
     "No se ha definido el tipo definido por el usuario",
     "Variable ya declarada",
     "Indice incorrecto",
     "Bucle mal anidado",
     "Se esperaba Entoces",
     "Se esperaba FinSi",
     "Funcion no definida",
     "Se esperaba fin instrucci�n",
     "Se esperaba instrucci�n",
     "Se esparaba Hasta",
     "Se esparaba FinDesde",
     "Variable esta en uso",
     "Mientras sin FinMientras",
     "Repetir sin HastaQue",
     "SegunSea sin FinSegunSea",
     "Divisi�n entre cero",
     "El �ndice esta fuera de intervalo",
     "No coinciden los tipos",
     "Argumento no es opcional",
     "Generacion codigo intermedio",
     "Desbordamiento",
     "Se esperaba parentesis",
     "Error de sintaxis",
     "Se esperaba una matriz",
     "Se esperaba una constante",
     "El intervalo no tiene valores",
     "Se esperaba cerrar parentesis )",
     "Se esperaba identificador",
     "N�mero argumentos erroneo",
     "Se ha detectado un nombre ambiguo",
     "Declaraci�n duplicada",
     "Expresi�n no valida",
     "Se esperaba variable",
     "C�racter no valido",
     "Argumento no valido",
     "Se esperaba igual =",
     "Referencia no valida",
     "Declaraci�n duplicada en el alcance actual",
     "Se esperaba nombre de tipo",
     "Tipo argumento no coincide",
     "El procedimiento externo no es valido"
};
