typedef union{
 TAtInfo info;
} YYSTYPE;
#define	T_ALGORITMO	258
#define	T_IDENT	259
#define	T_VAR	260
#define	T_ENTERO	261
#define	T_REAL	262
#define	T_CADENA	263
#define	T_LOGICO	264
#define	T_BEGIN	265
#define	T_END	266
#define	T_IF	267
#define	T_ENDIF	268
#define	T_THEN	269
#define	T_ELSE	270
#define	T_WHILE	271
#define	T_ENDW	272
#define	T_DO	273
#define	T_REPEAT	274
#define	T_UNTIL	275
#define	T_READ	276
#define	T_WRITE	277
#define	T_WRITELN	278
#define	T_CTEENTERA	279
#define	T_CTEREAL	280
#define	T_CTECADENA	281
#define	T_AND	282
#define	T_OR	283
#define	T_NOT	284
#define	T_ASIG	285
#define	T_DIF	286
#define	T_MENIG	287
#define	T_MAYIG	288
#define	T_DIV	289
#define	T_MOD	290
#define	T_ENDL	291
#define	T_FALSE	292
#define	T_TRUE	293
#define	T_FOR	294
#define	T_ENDFOR	295
#define	T_PASO	296
#define	T_FUNCION	297
#define	T_RETORNAR	298
#define	T_ARREGLO	299


extern YYSTYPE yylval;
