/* Autor : Jose Secundino Alvites Rodas
*  Fecha Creaci�n : Reque, Febrero del 2005
*  Email : josealvites@hotmail.com
*/

//---------------------------------------------------------------------------

#ifndef AlgoritmoH
#define AlgoritmoH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <Menus.hpp>
#include <ToolWin.hpp>
#include <ImgList.hpp>
#include <Dialogs.hpp>
#include <Grids.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TRichEdit *m_Documento;
        TStatusBar *StatusBar1;
        TMainMenu *MainMenu1;
        TMenuItem *Edicin1;
        TMenuItem *Deshacer1;
        TMenuItem *Rea1;
        TMenuItem *Cortar1;
        TMenuItem *Copiar1;
        TMenuItem *Pegar1;
        TMenuItem *Eliminar1;
        TMenuItem *Seleccionartodo1;
        TMenuItem *Buscar1;
        TMenuItem *Reemplazar1;
        TMenuItem *Ira1;
        TMenuItem *Fuente1;
        TMenuItem *Ejecutar1;
        TMenuItem *Iniciar1;
        TMenuItem *Ayuda1;
        TMenuItem *Contenido1;
        TMenuItem *Video1;
        TMenuItem *Acercade1;
        TToolBar *ToolBar1;
        TToolButton *ToolButton1;
        TToolButton *ToolButton2;
        TToolButton *ToolButton3;
        TToolButton *ToolButton4;
        TToolButton *ToolButton6;
        TImageList *ImageList1;
        TOpenDialog *OpenDialog1;
        TSaveDialog *SaveDialog1;
        TMenuItem *Archivo1;
        TMenuItem *Nuevo1;
        TMenuItem *Abrir1;
        TMenuItem *Guardar1;
        TMenuItem *Configurarinpresora1;
        TMenuItem *Imprimir1;
        TMenuItem *Salir1;
        TFontDialog *FontDialog1;
        TReplaceDialog *ReplaceDialog1;
        TPrintDialog *PrintDialog1;
        TPrinterSetupDialog *PrinterSetupDialog1;
        TPopupMenu *PopupMenu1;
        TMenuItem *Deshacer2;
        TMenuItem *Rehacer1;
        TMenuItem *Cortar2;
        TMenuItem *Copiar2;
        TMenuItem *Pegar2;
        TMenuItem *Eliminar2;
        TMenuItem *Seleccionartodo2;
        TFindDialog *FindDialog1;
        TToolButton *ToolButton8;
        TMenuItem *Estructuras1;
        TToolButton *ToolButton9;
        TToolButton *ToolButton10;
        TToolButton *ToolButton11;
        TToolButton *ToolButton12;
        TToolButton *ToolButton13;
        TToolButton *ToolButton14;
        TToolButton *ToolButton15;
        TToolButton *ToolButton16;
        TMenuItem *Ejecutarhastaelcursor2;
        TMenuItem *Ejecutarhastaelcursor3;
        TMenuItem *Terminar1;
        TToolButton *ToolButton5;
        TToolButton *ToolButton7;
        TToolButton *ToolButton17;
        TSplitter *Splitter1;
        TStringGrid *Vars;
        TToolButton *ToolButton18;
        TToolButton *Bloqueconcomentarios;
        TToolButton *Bloquesincomentarios;
        THeaderControl *HeaderControl1;
        TRichEdit *RichEdit1;
        TSplitter *Splitter2;
        void __fastcall m_DocumentoChange(TObject *Sender);
        void __fastcall m_DocumentoKeyUp(TObject *Sender, WORD &Key,
          TShiftState Shift);
        void __fastcall Abrir1Click(TObject *Sender);
        void __fastcall ToolButton2Click(TObject *Sender);
        void __fastcall Guardar1Click(TObject *Sender);
        void __fastcall ToolButton3Click(TObject *Sender);
        void __fastcall Seleccionartodo1Click(TObject *Sender);
        void __fastcall Copiar1Click(TObject *Sender);
        void __fastcall Pegar1Click(TObject *Sender);
        void __fastcall Cortar1Click(TObject *Sender);
        void __fastcall Eliminar1Click(TObject *Sender);
        void __fastcall Buscar1Click(TObject *Sender);
        void __fastcall Ira1Click(TObject *Sender);
        void __fastcall Nuevo1Click(TObject *Sender);
        void __fastcall ToolButton1Click(TObject *Sender);
        void __fastcall Salir1Click(TObject *Sender);
        void __fastcall Fuente1Click(TObject *Sender);
        void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
        void __fastcall Deshacer1Click(TObject *Sender);
        void __fastcall Rea1Click(TObject *Sender);
        void __fastcall Reemplazar1Click(TObject *Sender);
        
        void __fastcall ReplaceDialog1Replace(TObject *Sender);
        void __fastcall Imprimir1Click(TObject *Sender);
        void __fastcall Configurarinpresora1Click(TObject *Sender);
        void __fastcall Deshacer2Click(TObject *Sender);
        void __fastcall Rehacer1Click(TObject *Sender);
        void __fastcall Cortar2Click(TObject *Sender);
        void __fastcall Copiar2Click(TObject *Sender);
        void __fastcall Pegar2Click(TObject *Sender);
        void __fastcall Eliminar2Click(TObject *Sender);
        void __fastcall Seleccionartodo2Click(TObject *Sender);
        void __fastcall m_DocumentoMouseUp(TObject *Sender,
          TMouseButton Button, TShiftState Shift, int X, int Y);
        void __fastcall FindDialog1Find(TObject *Sender);
        void __fastcall ToolButton8Click(TObject *Sender);
        void __fastcall Estructuras1Click(TObject *Sender);
        void __fastcall ToolButton4Click(TObject *Sender);
        void __fastcall FormCreate(TObject *Sender);
        void __fastcall Acercade1Click(TObject *Sender);
        void __fastcall ToolButton9Click(TObject *Sender);
        void __fastcall ToolButton10Click(TObject *Sender);
        void __fastcall Iniciar1Click(TObject *Sender);
        void __fastcall ToolButton11Click(TObject *Sender);
        void __fastcall ToolButton12Click(TObject *Sender);
        void __fastcall ToolButton13Click(TObject *Sender);
        void __fastcall ToolButton15Click(TObject *Sender);
        void __fastcall ToolButton16Click(TObject *Sender);
        void __fastcall Ejecutarhastaelcursor2Click(TObject *Sender);
        void __fastcall Ejecutarhastaelcursor3Click(TObject *Sender);
        void __fastcall ToolButton6Click(TObject *Sender);
        void __fastcall Terminar1Click(TObject *Sender);
        void __fastcall BloqueconcomentariosClick(TObject *Sender);
        void __fastcall BloquesincomentariosClick(TObject *Sender);
private:	// User declarations

public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
      
        int PasoFila;
        int PtosInter[100];
        int estadoI;
        int SelStart;
        int SelLength;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
