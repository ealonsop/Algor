
/*  A Bison parser, made from algor.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define alloca

#define	T_ALGORITMO	258
#define	T_IDENT	259
#define	T_VAR	260
#define	T_ENTERO	261
#define	T_REAL	262
#define	T_CADENA	263
#define	T_LOGICO	264
#define	T_BEGIN	265
#define	T_END	266
#define	T_IF	267
#define	T_ENDIF	268
#define	T_THEN	269
#define	T_ELSE	270
#define	T_WHILE	271
#define	T_ENDW	272
#define	T_DO	273
#define	T_REPEAT	274
#define	T_UNTIL	275
#define	T_READ	276
#define	T_WRITE	277
#define	T_WRITELN	278
#define	T_CTEENTERA	279
#define	T_CTEREAL	280
#define	T_CTECADENA	281
#define	T_AND	282
#define	T_OR	283
#define	T_NOT	284
#define	T_ASIG	285
#define	T_DIF	286
#define	T_MENIG	287
#define	T_MAYIG	288
#define	T_DIV	289
#define	T_MOD	290
#define	T_ENDL	291
#define	T_FALSE	292
#define	T_TRUE	293
#define	T_FOR	294
#define	T_ENDFOR	295
#define	T_PASO	296
#define	T_FUNCION	297
#define	T_RETORNAR	298
#define	T_ARREGLO	299

#line 1 "algor.y"


#include "globales.h"
#include <conio.h>

extern void	imprimirTabla( TTS & TS, int valor );

void		yyerror( char * m )
{
	int linea;
	if ( *yytext == '\n' )
	{
	   linea = yyline-1;
	   *yytext = 0;
	}
	else
	   linea = yyline;
   yylineE = linea;
   if ( error == 0 )
 	   imprime( "\nError Sintactico. Linea: %d  Lexema: %s\n",
		  linea,  yytext );
	error = 1;
}

void		errorsemantico( char * m, TAtInfo & stk)
{
	char msg[150];
	sprintf(msg,"\nError Semantico. Linea: %d %s. Simbolo: '%s'\n",
	   stk.linea, m, ts_simbolo(TS,stk.ind) );
        yylineE = stk.linea;
   if ( error == 0 )
    	imprime(msg);
	error = 1;
}

void		errorsemantico( char * m, int linea)
{
	char msg[150];
	sprintf(msg,"\nError Semantico. Linea: %d %s",
	   linea, m );
        yylineE = linea;
   if ( error == 0 )
    	imprime(msg);
	error = 1;

}

void		errorejecucion( char * m, int linea)
{
	char msg[100];
	sprintf(msg,"\nError de Ejecucion. Linea: %d %s",
	   linea, m );
        yylineE = linea;
	if ( error == 0 )
      imprime(msg);
	error = 1;
}

int dims[100];

int tabla[17][10] = {
// 0  1  2  3  4  5  6  7 8   9
//   *-+ /  ^  DV MD R  L AS  RD
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//error
{  0, 1, 2, 1, 1, 1, 8, 0, 1, 1},//ii
{  0, 2, 2, 2, 0, 0, 8, 0, 1, 0},//ir
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//ic
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//ib
{  0, 2, 2, 2, 0, 0, 8, 0, 2, 0},//ri
{  0, 2, 2, 2, 0, 0, 8, 0, 2, 2},//rr
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//rc
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//rb
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//ci
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//cr
{  0, 0, 0, 0, 0, 0, 8, 0, 4, 1},//cc
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//cb
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//bi
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//br
{  0, 0, 0, 0, 0, 0, 0, 0, 0, 0},//bc
{  0, 0, 0, 0, 0, 0, 8, 8, 8, 0},//bb

};

int			op_tipo( int t1, int t2, int op )
{
  int col, fila;
  t1 = ts_tipo( t1 );
  t2 = ts_tipo( t2 );
  switch ( op ) {
    case '+' : case '-': case '*':
      col = 1; break;
	case '/' :
	  col = 2; break;
	case '^' :
	  col = 3; break;
	case T_DIV:
	  col = 4; break;
	case T_MOD:
	  col = 5; break;
	case '<': case '>': case T_MENIG: case T_MAYIG:
	case '=': case T_DIF:
	  col = 6; break;
	case T_AND: case T_OR: case T_NOT:
	  col = 7; break;
	case T_ASIG:
	  col = 8; break;
	case T_READ:
	  col = 9; break;
	default:
	 col = 0;
	 imprime("Error interno: operador desconcido: %d",op);
	 break;
  }
  switch ( (t1<<4)|t2 ){
   case (TIPO_ENTERO   <<4 ) |TIPO_ENTERO   : fila = 1; break;
   case (TIPO_ENTERO   <<4 ) |TIPO_REAL     : fila = 2; break;
   case (TIPO_ENTERO   <<4 ) |TIPO_CADENA   : fila = 3; break;
   case (TIPO_ENTERO   <<4 ) |TIPO_BOOL     : fila = 4; break;
   case (TIPO_REAL     <<4 ) |TIPO_ENTERO   : fila = 5; break;
   case (TIPO_REAL     <<4 ) |TIPO_REAL     : fila = 6; break;
   case (TIPO_REAL     <<4 ) |TIPO_CADENA   : fila = 7; break;
   case (TIPO_REAL     <<4 ) |TIPO_BOOL     : fila = 8; break;
   case (TIPO_CADENA   <<4 ) |TIPO_ENTERO   : fila = 9; break;
   case (TIPO_CADENA   <<4 ) |TIPO_REAL     : fila = 10; break;
   case (TIPO_CADENA   <<4 ) |TIPO_CADENA   : fila = 11; break;
   case (TIPO_CADENA   <<4 ) |TIPO_BOOL     : fila = 12; break;
   case (TIPO_BOOL     <<4 ) |TIPO_ENTERO   : fila = 13; break;
   case (TIPO_BOOL     <<4 ) |TIPO_REAL     : fila = 14; break;
   case (TIPO_BOOL     <<4 ) |TIPO_CADENA   : fila = 15; break;
   case (TIPO_BOOL     <<4 ) |TIPO_BOOL     : fila = 16; break;
   default:
     fila = 0;
	 imprime("Error interno: tipo desconcido: %x",(t1<<4)|t2);
  }
//  imprime("\nlinea: %d chk: %4x con %4x op: %c (%d %d)", yyline,t1,t2,op,fila,col);
  return tabla[fila][col];
}

int			chktipo( int t1, int t2, int op )
{
 int r;

 r = op_tipo( t1,t2,op );
 if ( r == 0 ) {
    errorsemantico( "tipos incompatibles", yyline );
 }
 else
    ;//imprime( "OK %4x", r );
 return r;
}

int yylineA;

int			gencode( int valor, int linea = 0 )
{
    int r;
    r = ip;
    if ( linea != 0 )
	   if ( yylineA != linea ) {
	      code[ip] = OP_LINEA;
		  code[ip+1] = linea;
		  yylineA = linea;
		  ip += 2;
	   }
	code[ip] = valor;
	ip++;
	return r;
}

int		chkConversion( int t1, int t2, int asig = 0);

int		chkConversion( int t1, int t2, int asig )
{
  int gen = ip;
  t1 = ts_tipo( t1 );
  t2 = ts_tipo( t2 );
  if ( t1 == TIPO_ENTERO && t2 == TIPO_REAL )
     if ( asig == 0 )
        gencode( OP_CVSREAL );
	 else
	    gencode( OP_CVTENTERO );
  else
  if ( t1 == TIPO_REAL && t2 == TIPO_ENTERO )
     gencode( OP_CVTREAL );
  return ip != gen;
}



#line 191 "algor.y"
typedef union{
 TAtInfo info;
} YYSTYPE;
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		218
#define	YYFLAG		32768
#define	YYNTBASE	59

#define YYTRANSLATE(x) ((unsigned)(x) <= 299 ? yytranslate[x] : 126)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,    51,
    52,    46,    45,    50,    54,     2,    47,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    56,     2,    48,
    55,    49,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
    57,     2,    58,    53,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     7,     9,    10,    14,    15,    17,    22,    23,    25,
    29,    31,    36,    42,    47,    48,    52,    54,    56,    58,
    60,    62,    64,    70,    72,    74,    75,    78,    80,    83,
    85,    87,    89,    91,    93,    95,    97,    99,   101,   103,
   107,   111,   113,   116,   120,   122,   124,   128,   130,   132,
   140,   143,   146,   147,   149,   151,   158,   161,   174,   175,
   176,   180,   181,   183,   184,   186,   188,   195,   199,   201,
   203,   208,   212,   214,   216,   220,   224,   226,   230,   234,
   238,   242,   244,   248,   250,   254,   257,   259,   261,   263,
   265,   267,   269,   271,   274,   276,   279,   283,   287,   291,
   293,   297,   299,   301,   304,   308,   310,   312,   314,   316,
   318,   320,   322,   324,   325,   328,   330,   334,   342,   344,
   346,   347,   351,   353,   357,   364
};

static const short yyrhs[] = {    60,
    61,   116,    62,    64,    63,     0,    75,     0,     0,     3,
     4,    75,     0,     0,    72,     0,    65,    75,    66,    75,
     0,     0,     5,     0,    66,    75,    67,     0,    67,     0,
     4,    68,    56,    70,     0,     4,    68,    71,    74,    67,
     0,    44,    57,    69,    58,     0,     0,    69,    50,    24,
     0,    24,     0,     6,     0,     7,     0,     8,     0,     9,
     0,    50,     0,    73,    36,    76,    11,    60,     0,    10,
     0,    36,     0,     0,    75,    36,     0,    36,     0,    76,
    77,     0,    77,     0,    78,     0,    81,     0,    80,     0,
    85,     0,    90,     0,    98,     0,    92,     0,    99,     0,
   103,     0,    21,    79,    36,     0,    79,    50,   100,     0,
   100,     0,    23,    36,     0,    82,    83,    36,     0,    22,
     0,    23,     0,    83,    50,    84,     0,    84,     0,   111,
     0,    12,    89,    86,    76,    87,    13,    36,     0,    14,
    36,     0,    88,    76,     0,     0,    15,     0,   111,     0,
    16,    89,    91,    76,    17,    36,     0,    18,    36,     0,
    39,    99,    93,    20,   111,    94,    95,    18,    36,    76,
    40,    36,     0,     0,     0,    41,    96,    97,     0,     0,
    54,     0,     0,    24,     0,    25,     0,    19,    36,    76,
    20,    89,    36,     0,   100,    30,   111,     0,     4,     0,
   101,     0,     4,    57,   102,    58,     0,   102,    50,   104,
     0,   104,     0,    36,     0,   104,    45,   105,     0,   104,
    54,   105,     0,   105,     0,   105,    46,   106,     0,   105,
    47,   106,     0,   105,    34,   106,     0,   105,    35,   106,
     0,   106,     0,   107,    53,   106,     0,   107,     0,    51,
   111,    52,     0,    54,   107,     0,   100,     0,    24,     0,
    25,     0,    26,     0,    37,     0,    38,     0,   108,     0,
   109,    52,     0,   110,     0,     4,    51,     0,   110,    50,
   111,     0,     4,    51,   111,     0,   111,    28,   112,     0,
   112,     0,   112,    27,   113,     0,   113,     0,   114,     0,
    29,   113,     0,   104,   115,   104,     0,   104,     0,    48,
     0,    49,     0,    55,     0,    31,     0,    32,     0,    33,
     0,   117,     0,     0,   117,   118,     0,   118,     0,   119,
    64,   124,     0,    42,    70,   120,    51,   121,    52,    75,
     0,     4,     0,   122,     0,     0,   122,    50,   123,     0,
   123,     0,     4,    56,    70,     0,    73,    36,    76,   125,
    11,    60,     0,    43,   111,    36,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   325,   341,   345,   351,   365,   372,   378,   382,   387,   394,
   398,   403,   424,   446,   450,   455,   460,   466,   471,   476,
   481,   488,   493,   501,   508,   512,   519,   523,   530,   534,
   540,   544,   548,   552,   556,   560,   564,   568,   572,   578,
   584,   605,   629,   637,   645,   651,   660,   664,   670,   677,
   688,   695,   700,   707,   714,   720,   731,   738,   796,   803,
   812,   820,   826,   830,   836,   841,   848,   857,   882,   888,
   895,   914,   921,   930,   936,   943,   950,   956,   963,   973,
   979,   985,   991,   998,  1004,  1008,  1014,  1033,  1040,  1047,
  1054,  1061,  1068,  1075,  1100,  1104,  1129,  1143,  1175,  1181,
  1187,  1193,  1200,  1204,  1212,  1219,  1226,  1232,  1237,  1242,
  1247,  1252,  1259,  1263,  1267,  1271,  1276,  1290,  1300,  1312,
  1316,  1321,  1326,  1332,  1348,  1355
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","T_ALGORITMO",
"T_IDENT","T_VAR","T_ENTERO","T_REAL","T_CADENA","T_LOGICO","T_BEGIN","T_END",
"T_IF","T_ENDIF","T_THEN","T_ELSE","T_WHILE","T_ENDW","T_DO","T_REPEAT","T_UNTIL",
"T_READ","T_WRITE","T_WRITELN","T_CTEENTERA","T_CTEREAL","T_CTECADENA","T_AND",
"T_OR","T_NOT","T_ASIG","T_DIF","T_MENIG","T_MAYIG","T_DIV","T_MOD","T_ENDL",
"T_FALSE","T_TRUE","T_FOR","T_ENDFOR","T_PASO","T_FUNCION","T_RETORNAR","T_ARREGLO",
"'+'","'*'","'/'","'<'","'>'","','","'('","')'","'^'","'-'","'='","':'","'['",
"']'","programa","lendlo","encab","inicio_prog","bloque","decl_var","pal_variables",
"lista_dcl","una_dcl","decarreglo","lista_decarreglo","tipo","sep","sent_comp",
"inicio","endlo","lendl","lista_sent","una_sent","sent_read","lista_idr","sent_writeln",
"sent_write","write","lista_salida","una_salida","sent_if","then","parte_else",
"else","condicion","sent_while","do","sent_para","vacio1","vacio2","paso","neg",
"constante","sent_repeat","sent_asig","varasig","vararreglo","lista_elemarreglo",
"sent_vacia","expresion","termino","pot","factor","llamada_funcion","parametros_reales",
"lista_parR","exp_condicional","ter_condicional","fac_condicional","exp_relacional",
"op_relacional","parte_funciones","lista_funciones","una_funcion","encab_funcion",
"nom_funcion","parametros_formales","lista_parametros","un_parametro","bloquefuncion",
"sent_retornar", NULL
};
#endif

static const short yyr1[] = {     0,
    59,    60,    60,    61,    62,    63,    64,    64,    65,    66,
    66,    67,    67,    68,    68,    69,    69,    70,    70,    70,
    70,    71,    72,    73,    74,    74,    75,    75,    76,    76,
    77,    77,    77,    77,    77,    77,    77,    77,    77,    78,
    79,    79,    80,    81,    82,    82,    83,    83,    84,    85,
    86,    87,    87,    88,    89,    90,    91,    92,    93,    94,
    95,    95,    96,    96,    97,    97,    98,    99,   100,   100,
   101,   102,   102,   103,   104,   104,   104,   105,   105,   105,
   105,   105,   106,   106,   107,   107,   107,   107,   107,   107,
   107,   107,   107,   108,   109,   109,   110,   110,   111,   111,
   112,   112,   113,   113,   114,   114,   115,   115,   115,   115,
   115,   115,   116,   116,   117,   117,   118,   119,   120,   121,
   121,   122,   122,   123,   124,   125
};

static const short yyr2[] = {     0,
     6,     1,     0,     3,     0,     1,     4,     0,     1,     3,
     1,     4,     5,     4,     0,     3,     1,     1,     1,     1,
     1,     1,     5,     1,     1,     0,     2,     1,     2,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     3,
     3,     1,     2,     3,     1,     1,     3,     1,     1,     7,
     2,     2,     0,     1,     1,     6,     2,    12,     0,     0,
     3,     0,     1,     0,     1,     1,     6,     3,     1,     1,
     4,     3,     1,     1,     3,     3,     1,     3,     3,     3,
     3,     1,     3,     1,     3,     2,     1,     1,     1,     1,
     1,     1,     1,     2,     1,     2,     3,     3,     3,     1,
     3,     1,     1,     2,     3,     1,     1,     1,     1,     1,
     1,     1,     1,     0,     2,     1,     3,     7,     1,     1,
     0,     3,     1,     3,     6,     3
};

static const short yydefact[] = {     3,
    28,     0,     2,     0,   114,    27,     0,     0,     5,   113,
   116,     8,     4,    18,    19,    20,    21,     0,     8,   115,
     9,     0,     0,   119,     0,     0,    24,     0,   117,     0,
   121,     1,     6,     0,     0,    15,     0,    11,     0,     0,
   120,   123,     0,    69,     0,     0,     0,     0,    45,    46,
    74,     0,     0,    30,    31,    33,    32,     0,    34,    35,
    37,    36,    38,     0,    70,    39,     0,     0,     7,     0,
     0,     0,     0,     0,    69,    88,    89,    90,     0,    91,
    92,     0,     0,     0,    87,   106,    77,    82,    84,    93,
     0,    95,    55,   100,   102,   103,     0,     0,     0,    42,
    43,    59,     0,    29,     0,     0,    48,    49,     0,     0,
    22,     0,    26,    10,   124,   118,   122,     3,     0,    73,
    96,   104,     0,    86,     0,     0,   110,   111,   112,     0,
   107,   108,     0,   109,     0,     0,     0,     0,     0,     0,
    94,     0,     0,     0,     0,     0,     0,    40,     0,     0,
     0,     3,    44,     0,    68,    17,     0,    12,    25,     0,
    23,     0,    71,    98,    85,    51,    53,    75,    76,   105,
    80,    81,    78,    79,    83,    97,    99,   101,    57,     0,
     0,    41,     0,   126,   125,    47,     0,    14,    13,    72,
    54,     0,     0,     0,     0,    60,    16,     0,    52,    56,
    67,    62,    50,    64,     0,    63,     0,     0,    65,    66,
    61,     0,     0,     0,    58,     0,     0,     0
};

static const short yydefgoto[] = {   216,
     2,     5,    19,    32,    22,    23,    37,    38,    68,   157,
    18,   113,    33,    28,   160,     3,    53,    54,    55,    99,
    56,    57,    58,   106,   107,    59,   126,   192,   193,    84,
    60,   146,    61,   150,   202,   205,   207,   211,    62,    63,
    85,    65,   119,    66,    86,    87,    88,    89,    90,    91,
    92,    93,    94,    95,    96,   135,     9,    10,    11,    12,
    25,    40,    41,    42,    29,   105
};

static const short yypact[] = {   -13,
-32768,    24,    12,    56,    20,-32768,   -13,   119,-32768,    20,
-32768,    59,    12,-32768,-32768,-32768,-32768,    71,    59,-32768,
-32768,    72,   -13,-32768,    30,    72,-32768,    52,-32768,    11,
    85,-32768,-32768,    58,   248,    48,   -13,-32768,    43,    49,
    65,-32768,   248,    51,     7,     7,    70,   114,-32768,    83,
-32768,   114,    64,-32768,-32768,-32768,-32768,     7,-32768,-32768,
-32768,-32768,-32768,    91,-32768,-32768,    73,    -1,    11,   119,
   -13,    85,   163,    16,    14,-32768,-32768,-32768,     7,-32768,
-32768,     7,    16,   120,-32768,   111,    63,-32768,    80,-32768,
    84,    89,   107,   122,-32768,-32768,   128,   248,   -22,-32768,
-32768,-32768,     7,-32768,   136,   -15,-32768,   107,     7,   126,
-32768,   119,   116,-32768,-32768,    12,-32768,   -13,   -34,     5,
     7,-32768,    -9,-32768,   117,   248,-32768,-32768,-32768,    16,
-32768,-32768,    16,-32768,    16,    16,    16,    16,    16,    16,
-32768,     7,     7,     7,   118,   248,   184,-32768,   114,   135,
    -2,   -13,-32768,     7,   107,-32768,   -21,-32768,-32768,   153,
-32768,    16,-32768,   107,-32768,-32768,   206,    63,    63,     5,
-32768,-32768,-32768,-32768,-32768,   107,   122,-32768,-32768,   227,
     7,-32768,     7,-32768,-32768,-32768,   137,-32768,-32768,     5,
-32768,   150,   248,   132,   133,   107,-32768,   140,   248,-32768,
-32768,   130,-32768,   127,   154,-32768,    54,   144,-32768,-32768,
-32768,   248,   101,   147,-32768,   173,   187,-32768
};

static const short yypgoto[] = {-32768,
  -106,-32768,-32768,-32768,   175,-32768,-32768,   -65,-32768,-32768,
   -60,-32768,-32768,   169,-32768,     2,   -42,   -51,-32768,-32768,
-32768,-32768,-32768,-32768,    44,-32768,-32768,-32768,-32768,   -43,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   145,
   -35,-32768,-32768,-32768,   -69,   -56,    53,   125,-32768,-32768,
-32768,   -52,    66,   -72,-32768,-32768,-32768,-32768,   191,-32768,
-32768,-32768,-32768,   139,-32768,-32768
};


#define	YYLAST		287


static const short yytable[] = {    64,
    73,   104,    97,   114,   120,   108,   122,    64,    13,   115,
    75,   161,   100,   148,    36,   162,    64,    64,   143,    75,
   153,   104,     1,   163,    30,   143,     4,   149,   187,   123,
    76,    77,    78,   184,   154,    79,   188,    64,    69,    76,
    77,    78,   165,    80,    81,   185,     6,     6,   111,   130,
   151,   158,    80,    81,   112,   147,   155,    82,   133,     7,
    83,     8,    64,    21,   121,   170,    82,    44,   164,    83,
    74,   178,   116,   168,    24,    45,   169,   209,   210,    46,
    31,    27,    47,   167,    48,    49,    50,    35,    39,   176,
    64,    67,   190,    43,   189,   104,   136,   137,    70,    51,
    71,   108,    52,   180,    44,    98,   103,    74,   138,   139,
    64,    64,    45,   182,    72,   104,    46,    44,   101,    47,
   109,    48,    49,    50,    14,    15,    16,    17,   104,   110,
   196,    64,   140,   125,   143,   141,    51,   195,   142,    52,
   214,   127,   128,   129,    64,   145,   152,   104,   144,   156,
   199,   159,   166,   179,   183,   130,    36,    64,   131,   132,
   197,   104,   198,    64,   133,   134,    44,   200,   201,   213,
   204,   208,   217,   118,    45,   203,    64,    64,    46,   212,
   206,    47,   215,    48,    49,    50,   218,    44,   171,   172,
   173,   174,   175,    26,    34,    45,   102,   186,    51,    46,
    20,    52,    47,   181,    48,    49,    50,   124,   177,    44,
   117,     0,     0,     0,     0,     0,     0,    45,     0,    51,
   191,    46,    52,     0,    47,     0,    48,    49,    50,     0,
    44,     0,     0,     0,     0,     0,     0,     0,    45,     0,
     0,    51,    46,   194,    52,    47,     0,    48,    49,    50,
     0,    44,     0,     0,     0,     0,     0,     0,     0,    45,
     0,     0,    51,    46,     0,    52,    47,     0,    48,    49,
    50,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,    51,     0,     0,    52
};

static const short yycheck[] = {    35,
    43,    53,    46,    69,    74,    58,    79,    43,     7,    70,
     4,   118,    48,    36,     4,    50,    52,    53,    28,     4,
    36,    73,    36,    58,    23,    28,     3,    50,    50,    82,
    24,    25,    26,    36,    50,    29,    58,    73,    37,    24,
    25,    26,    52,    37,    38,   152,    36,    36,    50,    45,
   103,   112,    37,    38,    56,    98,   109,    51,    54,     4,
    54,    42,    98,     5,    51,   135,    51,     4,   121,    54,
    57,   144,    71,   130,     4,    12,   133,    24,    25,    16,
    51,    10,    19,   126,    21,    22,    23,    36,     4,   142,
   126,    44,   162,    36,   160,   147,    34,    35,    56,    36,
    52,   154,    39,   146,     4,    36,    43,    57,    46,    47,
   146,   147,    12,   149,    50,   167,    16,     4,    36,    19,
    30,    21,    22,    23,     6,     7,     8,     9,   180,    57,
   183,   167,    53,    14,    28,    52,    36,   181,    50,    39,
    40,    31,    32,    33,   180,    18,    11,   199,    27,    24,
   193,    36,    36,    36,    20,    45,     4,   193,    48,    49,
    24,   213,    13,   199,    54,    55,     4,    36,    36,   212,
    41,    18,     0,    11,    12,    36,   212,   213,    16,    36,
    54,    19,    36,    21,    22,    23,     0,     4,   136,   137,
   138,   139,   140,    19,    26,    12,    52,   154,    36,    16,
    10,    39,    19,    20,    21,    22,    23,    83,   143,     4,
    72,    -1,    -1,    -1,    -1,    -1,    -1,    12,    -1,    36,
    15,    16,    39,    -1,    19,    -1,    21,    22,    23,    -1,
     4,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    12,    -1,
    -1,    36,    16,    17,    39,    19,    -1,    21,    22,    23,
    -1,     4,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    12,
    -1,    -1,    36,    16,    -1,    39,    19,    -1,    21,    22,
    23,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    36,    -1,    -1,    39
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif


/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 1:
#line 326 "algor.y"
{
					yyval.info = yyvsp[0].info;
               int posf, i;
               posf = yyvsp[-2].info.ind;
               TS.simbolos[posf].valor.funcion.pEntrada = yyvsp[0].info.dir;//MAIN2
               TS.simbolos[0].valor.funcion.pEntrada = yyvsp[0].info.dir;//MAIN
               for(i=0;i<TS.simbolos[0].valor.funcion.nFun;i++)
                TS.simbolos[posf].valor.funcion.funcs[i] =
                      TS.simbolos[0].valor.funcion.funcs[i];
               TS.simbolos[posf].valor.funcion.nFun =
                  TS.simbolos[0].valor.funcion.nFun;

				;
    break;}
case 2:
#line 342 "algor.y"
{
		    yyval.info = yyvsp[0].info;
		   ;
    break;}
case 3:
#line 346 "algor.y"
{
          yyval.info.dir = ip;
		  ;
    break;}
case 4:
#line 352 "algor.y"
{
					yyval.info = yyvsp[-2].info;
                                        ts_tipo(TS,yyvsp[-1].info.ind) = TIPO_PROG;
					ip = 0;
					yylineA = 0;
//					imprime("\n mem pp: %ld\n", coreleft() );
//		| {
//		    ip = 0;
//		    yylineA = 0;
//		  }
				;
    break;}
case 5:
#line 366 "algor.y"
{
              ts_agregafuncion(TS,"MAIN2",1);
              yyval.info.ind = TS.inicio;

            ;
    break;}
case 6:
#line 373 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 7:
#line 379 "algor.y"
{
					yyval.info = yyvsp[-3].info;
				;
    break;}
case 8:
#line 383 "algor.y"
{
            ;
    break;}
case 9:
#line 388 "algor.y"
{
               ts_adicionarctebool(TS,"false",0);
               ts_adicionarctebool(TS,"true",1);
               yyval.info = yyvsp[0].info;
             ;
    break;}
case 10:
#line 395 "algor.y"
{
				    yyval.info = yyvsp[-2].info;
				;
    break;}
case 11:
#line 399 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 12:
#line 404 "algor.y"
{
					yyval.info.tipo = yyvsp[0].info.tipo;
					if ( ! ts_EsNinguno(TS,yyvsp[-3].info.ind) )
						errorsemantico("variable multidefinida",yyvsp[-3].info);
					else
					{
                  if ( yyvsp[-2].info.aux == 0 )
                  {
						  ts_situarVariable(TS,yyvsp[-3].info.ind);
						  ts_cambiartipo(TS,yyvsp[-3].info.ind,yyvsp[0].info.tipo);
						//imprime( "\nDeclarando: %s como %x  ",
						//  ts_simbolo(TS,$1.ind), ts_tipo(TS,$1.ind));
                  }
                  else // arreglo
                   {
                    ts_agregaarreglo(TS,yyvsp[-3].info.ind,yyvsp[-2].info.aux,dims,yyvsp[0].info.tipo);
                   }
					}
				;
    break;}
case 13:
#line 425 "algor.y"
{
					yyval.info.tipo = yyvsp[0].info.tipo;
					if ( ! ts_EsNinguno(TS,yyvsp[-4].info.ind) )
						errorsemantico("variable multidefinida",yyvsp[-4].info);
					else
					{
                  if ( yyvsp[-3].info.aux == 0 )
                  {
						  ts_situarVariable(TS,yyvsp[-4].info.ind);
						  ts_cambiartipo(TS,yyvsp[-4].info.ind,yyvsp[0].info.tipo);
						//imprime( "\nDeclarando: %s como %x  ",
						//  ts_simbolo(TS,$1.ind), ts_tipo(TS,$1.ind));
                  }
                  else // arreglo
                   {
                    ts_agregaarreglo(TS,yyvsp[-4].info.ind,yyvsp[-3].info.aux,dims,yyvsp[0].info.tipo);
                   }
					}
				;
    break;}
case 14:
#line 447 "algor.y"
{
              yyval.info.aux = yyvsp[-1].info.aux;
            ;
    break;}
case 15:
#line 451 "algor.y"
{
              yyval.info.aux = 0;
            ;
    break;}
case 16:
#line 456 "algor.y"
{
             yyval.info.aux = yyvsp[-2].info.aux + 1;
              dims[yyval.info.aux-1] = ts_valor(TS,yyvsp[0].info.ind).entero;
           ;
    break;}
case 17:
#line 461 "algor.y"
{
              yyval.info.aux = 1;
              dims[yyval.info.aux-1] = ts_valor(TS,yyvsp[0].info.ind).entero;
          ;
    break;}
case 18:
#line 467 "algor.y"
{
				  yyval.info = yyvsp[0].info;
				  yyval.info.tipo = TIPO_ENTERO;
				;
    break;}
case 19:
#line 472 "algor.y"
{
				  yyval.info = yyvsp[0].info;
				  yyval.info.tipo = TIPO_REAL;
				;
    break;}
case 20:
#line 477 "algor.y"
{
				  yyval.info = yyvsp[0].info;
				  yyval.info.tipo = TIPO_CADENA;
				;
    break;}
case 21:
#line 482 "algor.y"
{
				  yyval.info = yyvsp[0].info;
				  yyval.info.tipo = TIPO_BOOL;
				;
    break;}
case 22:
#line 489 "algor.y"
{
				;
    break;}
case 23:
#line 494 "algor.y"
{
					yyval.info = yyvsp[-4].info;
					gencode( OP_NOP, yyvsp[-1].info.linea );
//					imprime("\n mem ff: %ld\n", coreleft() );
				;
    break;}
case 24:
#line 502 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.dir = ip;
               gencode( OP_NOP, yyvsp[0].info.linea );
				;
    break;}
case 25:
#line 509 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 26:
#line 513 "algor.y"
{
					;
				;
    break;}
case 27:
#line 520 "algor.y"
{
					yyval.info = yyvsp[-1].info;
				;
    break;}
case 28:
#line 524 "algor.y"
{
					yyval.info = yyvsp[0].info;
               yyval.info.dir = ip;
				;
    break;}
case 29:
#line 531 "algor.y"
{
					yyval.info = yyvsp[-1].info;
				;
    break;}
case 30:
#line 535 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 31:
#line 541 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 32:
#line 545 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 33:
#line 549 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 34:
#line 553 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 35:
#line 557 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 36:
#line 561 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 37:
#line 565 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 38:
#line 569 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 39:
#line 573 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 40:
#line 579 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 41:
#line 585 "algor.y"
{
					yyval.info = yyvsp[-2].info;
               if ( !error ) {
					   gencode( OP_READ, yyvsp[0].info.linea );
					   gencode( ts_tipo( ts_tipo(TS,yyvsp[0].info.ind) ) );
		               chktipo( ts_tipo(TS,yyvsp[0].info.ind),
					            ts_tipo(TS,yyvsp[0].info.ind), T_READ );

					   if ( ! ts_EsVariable(TS,yyvsp[0].info.ind) && yyvsp[0].info.aux == 0 )
						   errorsemantico("variable sin definir",yyvsp[-2].info);
					   else
						   if ( yyvsp[0].info.aux == 0 )
                        ts_situarValor(TS,yyvsp[0].info.ind);
                  if ( yyvsp[0].info.aux == 0 )
                     gencode( OP_ASIG );
                  else
                     gencode( OP_ASIGARREGLO );
					   gencode( yyvsp[0].info.ind );
               }
				;
    break;}
case 42:
#line 606 "algor.y"
{
               yyval.info = yyvsp[0].info;
               if ( !error )
               {
					    yyval.info.dir = gencode( OP_READ, yyvsp[0].info.linea );
					    gencode( ts_tipo( ts_tipo(TS,yyvsp[0].info.ind) ) );
		                chktipo( ts_tipo(TS,yyvsp[0].info.ind),
					             ts_tipo(TS,yyvsp[0].info.ind), T_READ );
					    if ( ! ts_EsVariable(TS,yyvsp[0].info.ind) && yyvsp[0].info.aux == 0 )
						    errorsemantico("variable sin definir",yyvsp[0].info);
					    else
                      if ( yyvsp[0].info.aux == 0 )
						       ts_situarValor(TS,yyvsp[0].info.ind);
                   if ( yyvsp[0].info.aux == 0 )
                      gencode( OP_ASIG );
                   else
                     gencode( OP_ASIGARREGLO );
					    gencode( yyvsp[0].info.ind );
               }
				;
    break;}
case 43:
#line 630 "algor.y"
{
			    yyval.info = yyvsp[-1].info;

			    yyval.info.dir = gencode( OP_WRITELN, yyvsp[-1].info.linea );
			  ;
    break;}
case 44:
#line 638 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					if ( yyvsp[-2].info.aux == 1 )
					   gencode( OP_WRITELN, yyvsp[-2].info.linea )
				;
    break;}
case 45:
#line 646 "algor.y"
{
			    yyval.info = yyvsp[0].info;
             yyval.info.dir = ip;
			    yyval.info.aux = 0;
			  ;
    break;}
case 46:
#line 653 "algor.y"
{
				yyval.info = yyvsp[0].info;
            yyval.info.dir = ip;
				yyval.info.aux = 1;
			  ;
    break;}
case 47:
#line 661 "algor.y"
{
					yyval.info = yyvsp[-2].info;
				;
    break;}
case 48:
#line 665 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 49:
#line 671 "algor.y"
{
					yyval.info = yyvsp[0].info;
					gencode( OP_WRITE, yyvsp[0].info.linea );
				;
    break;}
case 50:
#line 678 "algor.y"
{
					yyval.info = yyvsp[-5].info;
					if ( yyvsp[-5].info.tipo != TIPO_BOOL )
					   errorsemantico("la condicion debe ser booleana",yyvsp[-6].info.linea);
					if ( yyvsp[-2].info.aux == 1 ) // hay else
						code[yyvsp[-2].info.dir-1] = ip; // el OP_SI
					code[yyvsp[-4].info.dir+1] = yyvsp[-2].info.dir; // el OP_SSF
				;
    break;}
case 51:
#line 689 "algor.y"
{
					yyval.info.dir = gencode( OP_SSF );
					gencode(-1);
				;
    break;}
case 52:
#line 696 "algor.y"
{
					yyval.info.dir = yyvsp[0].info.dir;
					yyval.info.aux = 1;
				;
    break;}
case 53:
#line 701 "algor.y"
{
					yyval.info.dir = ip;
					yyval.info.aux = 0;
				;
    break;}
case 54:
#line 708 "algor.y"
{
					yyval.info.dir = gencode( OP_SI );
					gencode(-1);
				;
    break;}
case 55:
#line 715 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 56:
#line 721 "algor.y"
{
					yyval.info = yyvsp[-4].info;
					if ( yyvsp[-4].info.tipo != TIPO_BOOL )
					   errorsemantico("la condicion debe ser booleana",yyvsp[-5].info.linea);
					gencode( OP_SI );
					gencode( yyvsp[-4].info.dir );
					code[yyvsp[-3].info.dir+1] = ip;
				;
    break;}
case 57:
#line 732 "algor.y"
{
					yyval.info.dir = gencode( OP_SSF );
					gencode(-1);
				;
    break;}
case 58:
#line 739 "algor.y"
{
                   yyval.info = yyvsp[-11].info;
                   yyval.info.dir = yyvsp[-10].info.dir;
                   gencode( OP_CARGAVAL );
                   gencode( yyvsp[-10].info.ind );
                   gencode( OP_CARGAVAL );
                   int t1 = ts_tipo( ts_tipo(TS,yyvsp[-10].info.ind) );
                   if ( yyvsp[-5].info.aux == 0 ) // sin paso
                   {
                      if ( ts_EsEntero(TS,yyvsp[-10].info.ind) )
                         gencode( ts_adicionarcteentera( TS,"1" ) );
                      else
                         gencode( ts_adicionarctereal( TS,"1.0" ) );
                      gencode( OP_SUMA );
                   }
                   else // con paso
                   {
                      gencode( yyvsp[-5].info.ind ); // verificar tipo.
                      if ( t1 == TIPO_ENTERO && yyvsp[-5].info.tipo == TIPO_REAL )
                         gencode( OP_CVTENTERO );
                      else
                      if ( t1 == TIPO_REAL && yyvsp[-5].info.tipo == TIPO_ENTERO )
                         gencode( OP_CVTREAL );

                      if ( yyvsp[-5].info.aux == 2 ) {
                         gencode( OP_RESTA );
                         code[ yyvsp[-6].info.dir+1 ] = OP_MAYIG;
                      }
                      else {
                         gencode( OP_SUMA );
                      }

                   }

                   gencode( OP_ASIG );
                   gencode( yyvsp[-10].info.ind );
                   gencode( OP_SI );
                   gencode( yyvsp[-9].info.dir );
                   code[ yyvsp[-9].info.dir+1 ] = yyvsp[-10].info.ind; // variable para el <=
                   code[ yyvsp[-6].info.dir+3 ] = ip; // SSF
                   if ( !ts_EsNumerico(TS,yyvsp[-10].info.ind) )
			 errorsemantico("la variable debe ser numerica",yyvsp[-10].info);
                   int t2 = ts_tipo(yyvsp[-7].info.tipo);
                   if ( t2 != TIPO_ENTERO && t2 != TIPO_REAL )
                         errorsemantico("la expresion final debe ser numerica",yyvsp[-8].info.linea);
                   if ( t1 == t2 )
                      code[yyvsp[-6].info.dir] = OP_NOP;
                   else
                   {
                      int auxip = ip;
                      ip = yyvsp[-6].info.dir;
                      chkConversion(t1,t2);
                      ip = auxip;
                   }
                 ;
    break;}
case 59:
#line 797 "algor.y"
{
                  yyval.info.dir = gencode( OP_CARGAVAL );
                  gencode( -1 );
                ;
    break;}
case 60:
#line 804 "algor.y"
{
                  yyval.info.dir = gencode( -1 );
                  gencode( OP_MENIG );
                  gencode( OP_SSF );
                  gencode( -1 );
               ;
    break;}
case 61:
#line 813 "algor.y"
{
                  yyval.info = yyvsp[-2].info;
                  yyval.info.aux = yyvsp[-1].info.aux;
                  yyval.info.ind = yyvsp[0].info.ind;
                  yyval.info.tipo = yyvsp[0].info.tipo;
               ;
    break;}
case 62:
#line 821 "algor.y"
{
                 yyval.info.aux = 0;
               ;
    break;}
case 63:
#line 827 "algor.y"
{
                 yyval.info.aux = 2;
               ;
    break;}
case 64:
#line 831 "algor.y"
{
                 yyval.info.aux = 1;
               ;
    break;}
case 65:
#line 837 "algor.y"
{
                  yyval.info.ind = yyvsp[0].info.ind;
                  yyval.info.tipo = TIPO_ENTERO;
               ;
    break;}
case 66:
#line 842 "algor.y"
{
                  yyval.info.ind = yyvsp[0].info.ind;
                  yyval.info.tipo = TIPO_REAL;
               ;
    break;}
case 67:
#line 849 "algor.y"
{
			  yyval.info = yyvsp[-3].info;
			  if ( yyvsp[-1].info.tipo != TIPO_BOOL )
			     errorsemantico("la condicion debe ser booleana",yyvsp[-2].info.linea);
			  gencode( OP_SSF );
			  gencode( yyvsp[-3].info.dir );
                 ;
    break;}
case 68:
#line 858 "algor.y"
{
					yyval.info = yyvsp[-2].info;
               if ( !error )
               {
					   if ( ! ts_EsVariable(TS,yyvsp[-2].info.ind) && yyvsp[-2].info.aux == 0 )
						   errorsemantico("variable sin definir",yyvsp[-2].info);
					   else {
					       if ( yyvsp[0].info.tipo != 0 ) {
		                      yyval.info.tipo = chktipo(
						         ts_tipo(TS,yyvsp[-2].info.ind), yyvsp[0].info.tipo, T_ASIG );
						      chkConversion(ts_tipo(TS,yyvsp[-2].info.ind),yyvsp[0].info.tipo,1);
						      ts_situarValor(TS,yyvsp[-2].info.ind);
						   }
					   }
                  yyval.info.ind = yyvsp[-2].info.ind;
                  if ( yyvsp[-2].info.aux == 0 )
					      gencode( OP_ASIG );
                  else
                     gencode( OP_ASIGARREGLO );
					   gencode( yyvsp[-2].info.ind );
               }
				;
    break;}
case 69:
#line 883 "algor.y"
{
              yyval.info = yyvsp[0].info;
              yyval.info.aux = 0;
              yyval.info.dir = ip;
            ;
    break;}
case 70:
#line 889 "algor.y"
{
              yyval.info = yyvsp[0].info;
              yyval.info.aux = 1;
            ;
    break;}
case 71:
#line 896 "algor.y"
{
              if (! (ts_tipo(TS,yyvsp[-3].info.ind) & TIPO_ARREGLO))
                 errorsemantico("la variable no es un arreglo",yyvsp[-3].info);
              else
              {
                if ( ts_valor(TS,yyvsp[-3].info.ind).arreglo.tDim != yyvsp[-1].info.aux )
                   errorsemantico("la cantidad de indices no coincide con la declaracion",yyvsp[-3].info);
                else
                {
                   gencode( OP_CALCOFFSET );
                   gencode( yyvsp[-3].info.ind );
                }

              }
              yyval.info  = yyvsp[-1].info;
              yyval.info.ind = yyvsp[-3].info.ind;
            ;
    break;}
case 72:
#line 915 "algor.y"
{
              yyval.info = yyvsp[-2].info;
              yyval.info.aux = yyvsp[-2].info.aux + 1;
              if ( yyvsp[0].info.tipo != TIPO_ENTERO )
                 errorsemantico("los indices tienen que ser enteros",yyvsp[-2].info.linea);
            ;
    break;}
case 73:
#line 923 "algor.y"
{
              yyval.info = yyvsp[0].info;
              yyval.info.aux = 1;
              if ( yyvsp[0].info.tipo != TIPO_ENTERO )
                 errorsemantico("los indices tienen que ser enteros",yyvsp[0].info.linea);
            ;
    break;}
case 74:
#line 931 "algor.y"
{
					yyval.info.dir = ip;
				;
    break;}
case 75:
#line 937 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, '+' );
					chkConversion(yyvsp[-2].info.tipo,yyvsp[0].info.tipo);
					gencode( OP_SUMA, yyvsp[-1].info.linea );
				;
    break;}
case 76:
#line 944 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, '-' );
					chkConversion(yyvsp[-2].info.tipo,yyvsp[0].info.tipo);
					gencode( OP_RESTA, yyvsp[-1].info.linea );
				;
    break;}
case 77:
#line 951 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 78:
#line 957 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, '*' );
					chkConversion(yyvsp[-2].info.tipo,yyvsp[0].info.tipo);
					gencode( OP_MULT, yyvsp[-1].info.linea );
				;
    break;}
case 79:
#line 964 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, '/' );
					if ( ts_tipo(yyvsp[-2].info.tipo) == TIPO_ENTERO )
					   gencode( OP_CVSREAL );
					if ( ts_tipo(yyvsp[0].info.tipo) == TIPO_ENTERO )
					   gencode( OP_CVTREAL );
					gencode( OP_DIV, yyvsp[-1].info.linea );
				;
    break;}
case 80:
#line 974 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, T_DIV );
					gencode( OP_DIVENT, yyvsp[-1].info.linea );
				;
    break;}
case 81:
#line 980 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, T_MOD );
					gencode( OP_MOD, yyvsp[-1].info.linea );
				;
    break;}
case 82:
#line 986 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 83:
#line 992 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, '^' );
					chkConversion(yyvsp[-2].info.tipo,yyvsp[0].info.tipo);
					gencode( OP_POT, yyvsp[-1].info.linea );
				;
    break;}
case 84:
#line 999 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 85:
#line 1005 "algor.y"
{
					yyval.info = yyvsp[-1].info;
				;
    break;}
case 86:
#line 1009 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.tipo = chktipo( yyvsp[0].info.tipo, yyvsp[0].info.tipo, '-' );
					gencode( OP_NEG, yyvsp[-1].info.linea );
				;
    break;}
case 87:
#line 1015 "algor.y"
{
				   yyval.info = yyvsp[0].info;
               if ( !error )
               {
					if ( ! ts_EsVariable(TS,yyvsp[0].info.ind) && yyval.info.aux == 0 )
						errorsemantico("variable sin definir",yyvsp[0].info);
					else {
					   yyval.info.tipo = ts_tipo( ts_tipo(TS,yyvsp[0].info.ind) );
						if ( ! ts_TieneValor( TS,yyvsp[0].info.ind) && yyval.info.aux == 0 )
						   errorsemantico("variable sin valor",yyvsp[0].info);
					}
               if ( yyvsp[0].info.aux == 0 )
					  yyval.info.dir = gencode( OP_CARGAVAL, yyvsp[0].info.linea );
               else
					  gencode( OP_CARGAARREGLO, yyvsp[0].info.linea );
					gencode( yyvsp[0].info.ind );
               }
				;
    break;}
case 88:
#line 1034 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.tipo = TIPO_ENTERO;
					yyval.info.dir = gencode( OP_CARGAVAL, yyvsp[0].info.linea  );
					gencode( yyvsp[0].info.ind );
				;
    break;}
case 89:
#line 1041 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.tipo = TIPO_REAL;
					yyval.info.dir = gencode( OP_CARGAVAL, yyvsp[0].info.linea );
					gencode( yyvsp[0].info.ind );
				;
    break;}
case 90:
#line 1048 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.tipo = TIPO_CADENA;
					yyval.info.dir = gencode( OP_CARGAVAL, yyvsp[0].info.linea );
					gencode( yyvsp[0].info.ind );
				;
    break;}
case 91:
#line 1055 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.tipo = TIPO_BOOL;
					yyval.info.dir = gencode( OP_CARGAVAL, yyvsp[0].info.linea );
					gencode( ts_buscar(TS,"false") ); // posicion del falso en la TS
				;
    break;}
case 92:
#line 1062 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.tipo = TIPO_BOOL;
					yyval.info.dir = gencode( OP_CARGAVAL, yyvsp[0].info.linea );
					gencode( ts_buscar(TS,"true") ); // posicion del verdadero en la TS
				;
    break;}
case 93:
#line 1069 "algor.y"
{
             yyval.info = yyvsp[0].info;
           ;
    break;}
case 94:
#line 1076 "algor.y"
{
            int posf, cpar;
            yyval.info = yyvsp[-1].info; // .dir .tipo .ind, .aux(cant de par)
            if ( error == 0 ) {
               int posf = ts_buscarfuncion(TS,yyvsp[-1].info.ind);
               if ( posf == -1 )
	                imprime("Error interno en busq. de funcion");
               cpar = TS.simbolos[posf].valor.funcion.tPar;
//               imprime("\nFuncion: %s Parametros: %d Llamada: %d\n",
//                TS.simbolos[posf].simbolo, cpar, $1.aux );
               if ( cpar > yyvsp[-1].info.aux )
                  errorsemantico("faltan parametros en la funcion",yyvsp[-1].info);
               else
                 if ( cpar < yyvsp[-1].info.aux )
                     errorsemantico("demasiados parametros en la funcion",yyvsp[-1].info);
                 else {
//                   imprime("generando CALL: %d", posf );
                  // getch();
                   gencode( OP_CALL, yyvsp[0].info.linea );
                   gencode( posf );
                 }
            }
          ;
    break;}
case 95:
#line 1101 "algor.y"
{
            yyval.info = yyvsp[0].info; // ind, dir, tipo, aux
          ;
    break;}
case 96:
#line 1105 "algor.y"
{
           int posf = ts_buscarfuncion(TS,yyvsp[-1].info.ind);
           if ( posf == -1 || yyvsp[-1].info.ind == 0 ) {
              if ( posf == -1 )
                 errorsemantico("funcion no definida",yyvsp[-1].info);
              else
                 errorsemantico("no se permiten llamadas recursivas",yyvsp[-1].info);
                 // para evitar el error interno
                 yyval.info.tipo = TIPO_ENTERO;
              }
           else
           {
             yyval.info.tipo = ts_tipo(TS.simbolos[posf].tipo);
   //          imprime("tipo de la funcion: %x", $$.tipo );
             if ( TS.simbolos[posf].valor.funcion.tPar != 0 ) {
                errorsemantico("faltan los parametros de la funcion",yyvsp[-1].info);
             }
             yyval.info.dir = ip;
             yyval.info.ind = yyvsp[-1].info.ind;
             yyval.info.aux = 0;
           }
          ;
    break;}
case 97:
#line 1130 "algor.y"
{
             yyval.info = yyvsp[-2].info; // ind, dir, tipo
             yyval.info.aux = yyvsp[-2].info.aux + 1;
             if  ( error == 0 ) {
                int posf = ts_buscarfuncion(TS,yyvsp[-2].info.ind);
                if ( yyvsp[0].info.tipo != 0 ) {
                   int tipopar;
                   tipopar = ts_tipo(TS.simbolos[posf+yyval.info.aux].tipo);
		             chktipo( tipopar, yyvsp[0].info.tipo, T_ASIG );
						 chkConversion(tipopar,yyvsp[0].info.tipo,1);
						}
             }
           ;
    break;}
case 98:
#line 1145 "algor.y"
{
              int posf = ts_buscarfuncion(TS,yyvsp[-2].info.ind);
              if ( posf == -1 || yyvsp[-2].info.ind == 0 ) {
                 if ( posf == -1 )
                    errorsemantico("funcion no definida",yyvsp[-2].info);
                 else
                    errorsemantico("no se permiten llamadas recursivas",yyvsp[-2].info);
                 // para evitar el error interno
                 yyval.info.tipo = TIPO_ENTERO;
              }
              else {
               yyval.info.tipo = ts_tipo(TS.simbolos[posf].tipo);
               if ( TS.simbolos[posf].valor.funcion.tPar == 0 )
                errorsemantico("la funcion no tiene parametros",yyvsp[-2].info);
               else
               {
                yyval.info.aux = 1;
                if ( yyvsp[0].info.tipo != 0 ) {
                   int tipopar;
                   tipopar = ts_tipo(TS.simbolos[posf+yyval.info.aux].tipo);
		             chktipo( tipopar, yyvsp[0].info.tipo, T_ASIG );
						 chkConversion(tipopar,yyvsp[0].info.tipo,1);
						}
                yyval.info.ind = yyvsp[-2].info.ind;
                yyval.info.aux = 1;
                yyval.info.dir = yyvsp[0].info.dir;
              }
             }
           ;
    break;}
case 99:
#line 1176 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, T_OR );
					gencode( OP_OR, yyvsp[-1].info.linea );
				;
    break;}
case 100:
#line 1182 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 101:
#line 1188 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, T_AND );
					gencode( OP_AND, yyvsp[-1].info.linea );
				;
    break;}
case 102:
#line 1194 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 103:
#line 1201 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 104:
#line 1205 "algor.y"
{
					yyval.info = yyvsp[-1].info;
					yyval.info.tipo = chktipo( yyvsp[0].info.tipo, yyvsp[0].info.tipo, T_AND );
					gencode( OP_NOT, yyvsp[-1].info.linea );
				;
    break;}
case 105:
#line 1213 "algor.y"
{
					yyval.info = yyvsp[-2].info;
					yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, '<' );
					chkConversion(yyvsp[-2].info.tipo,yyvsp[0].info.tipo);
					gencode( yyvsp[-1].info.aux, yyvsp[-1].info.linea );
				;
    break;}
case 106:
#line 1221 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 107:
#line 1227 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.aux = OP_MENOR;

				;
    break;}
case 108:
#line 1233 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.aux = OP_MAYOR;
				;
    break;}
case 109:
#line 1238 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.aux = OP_IG;
				;
    break;}
case 110:
#line 1243 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.aux = OP_DIF;
				;
    break;}
case 111:
#line 1248 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.aux = OP_MENIG;
				;
    break;}
case 112:
#line 1253 "algor.y"
{
					yyval.info = yyvsp[0].info;
					yyval.info.aux = OP_MAYIG;
				;
    break;}
case 113:
#line 1260 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 114:
#line 1264 "algor.y"
{
				;
    break;}
case 115:
#line 1268 "algor.y"
{
					yyval.info = yyvsp[-1].info;
				;
    break;}
case 116:
#line 1272 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 117:
#line 1277 "algor.y"
{
					yyval.info = yyvsp[-2].info;
               int posf = yyvsp[-2].info.ind;
               TS.simbolos[posf].valor.funcion.pEntrada = yyvsp[0].info.dir;//FUNCION
               TS.simbolos[posf].tipo |= yyvsp[-2].info.tipo;

               if ( !error ) {
	               yyval.info.tipo = chktipo( yyvsp[-2].info.tipo, yyvsp[0].info.tipo, T_ASIG );
	               chkConversion(yyvsp[-2].info.tipo,yyvsp[0].info.tipo,1);
                  gencode( OP_RET, yyvsp[0].info.aux );//linea
               }
		;
    break;}
case 118:
#line 1291 "algor.y"
{
               int posf;
               posf = yyvsp[-4].info.ind;
					yyval.info = yyvsp[-4].info;
               yyval.info.tipo = yyvsp[-5].info.tipo;
               TS.simbolos[posf].valor.funcion.tPar = yyvsp[-2].info.aux;
				;
    break;}
case 119:
#line 1301 "algor.y"
{
              // verificar que no exista otra funcion con ese nombre
              // OJO OJO OJO
              ts_agregafuncion( TS, "", 0 );
              int posf;
              posf = TS.simbolos[0].valor.funcion.nFun++;
              TS.simbolos[0].valor.funcion.funcs[posf] = TS.inicio;
              yyval.info  = yyvsp[0].info;
              yyval.info.ind = TS.inicio;
             ;
    break;}
case 120:
#line 1313 "algor.y"
{
					yyval.info = yyvsp[0].info;
				;
    break;}
case 121:
#line 1317 "algor.y"
{
               yyval.info.aux = 0;
				;
    break;}
case 122:
#line 1322 "algor.y"
{
					yyval.info = yyvsp[-2].info;
               yyval.info.aux = yyvsp[-2].info.aux + 1;
				;
    break;}
case 123:
#line 1327 "algor.y"
{
					yyval.info = yyvsp[0].info;
               yyval.info.aux = 1;
				;
    break;}
case 124:
#line 1333 "algor.y"
{
//					$$ = $1;
					yyval.info.tipo = yyvsp[0].info.tipo;
					if ( ! ts_EsNinguno(TS,yyvsp[-2].info.ind) )
						errorsemantico("variable multidefinida",yyvsp[-2].info);
					else
					{
						ts_situarVariable(TS,yyvsp[-2].info.ind);
						ts_cambiartipo(TS,yyvsp[-2].info.ind,yyvsp[0].info.tipo);
                  ts_situarValor(TS,yyvsp[-2].info.ind);
						//imprime( "\nDeclarando: %s como %x  ",
						//  ts_simbolo(TS,$1.ind), ts_tipo(TS,$1.ind));
					}
				;
    break;}
case 125:
#line 1349 "algor.y"
{
					yyval.info = yyvsp[-5].info;
					yyval.info.tipo = yyvsp[-2].info.tipo;
					yyval.info.aux = yyvsp[-2].info.aux;
				;
    break;}
case 126:
#line 1356 "algor.y"
{
					yyval.info = yyvsp[-1].info;
					yyval.info.aux = yyvsp[-2].info.linea;
				;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 1362 "algor.y"


