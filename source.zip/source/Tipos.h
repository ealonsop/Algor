 /*
   Modulo             : Tipos.h
   Autor              : Jose Secundino Alvites Rodas
   Fecha Creacion     : Domingo 10 de Abril del 2005
   Fecha Actualizacion: 
   Pais               : Per�
   Asesor             : Ing. Eduardo Alonso P�rez
*/
#define TIPO_VARIABLE         0
#define TIPO_FUNCION          1 //Observado no existe
#define TIPO_CARACTER         2
#define TIPO_ENTERO           3
#define TIPO_REAL             4
#define TIPO_BOLEANO          5
#define TIPO_CADENA           6
#define TIPO_ARREGLO_CARACTER 7
#define TIPO_ARREGLO_ENTERO   8
#define TIPO_ARREGLO_REAL     9
#define TIPO_ARREGLO_BOLEANO  10
#define TIPO_VARIABLE_LOCAL   11
#define TIPO_VARIABLE_GLOBAL  12
#define TIPO_DESCONOCIDO      13
#define TIPO_CONSTANTE        14

/***************************************
* Estructura de las expresiones de tipos
****************************************/
typedef struct Tipo_Estructura{
               int Constructor;
               Tipo_Estructura *Izq;
               Tipo_Estructura *Der;
}Tipo;
