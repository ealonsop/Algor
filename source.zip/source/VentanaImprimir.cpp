//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include <qt.hpp>

#include "VentanaImprimir.h"
#include "Algoritmo.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm3 *Form3;
//---------------------------------------------------------------------------
__fastcall TForm3::TForm3(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm3::Leer_DatosChange(TObject *Sender)
{
     AnsiString NewString = "";

/*     if (InputQuery("SARPer�", "Ingrese valor", NewString))
         ShowMessage(NewString);*/

}
//---------------------------------------------------------------------------

void __fastcall TForm3::Imp_ResultadosKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
//  AnsiString A;
//  A = AnsiString(Key_F9);
//  ShowMessage(A);
  switch ( Key ) {
    case 120: Form1->ToolButton4Click(Sender); break;//F9
    case 121: Form1->ToolButton15Click(Sender); break;//F10
    case 122: Form1->ToolButton16Click(Sender); break; //F11
    case 123: Form1->ToolButton6Click(Sender); break;//F12
  }
}
//---------------------------------------------------------------------------

