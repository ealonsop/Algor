#include <stdio.h>
#include "interfaz.h"
#include "ts.h"
#include "opers.h"

struct TAtInfo
{
	int dir;
	int	ind;
	int tipo;
	int aux;
	int linea;
};


#define T_EOF	0
#define T_ERROR	1000


extern	char * yytext;  // definido en lo q genera el FLEX
extern FILE * yyin;		// definido en lo q genera el FLEX

extern int yylex();		// generada por FLEX
extern int yyparse();	// generada por BISON

extern  int     yylineE;       // definido en Interp.cpp
extern	int	yyline;		// definido en pascal.cpp
extern	TTS	TS;			// definido en pascal.cpp

extern	int ip;			// definido en pascal.cpp
extern  int	*code;		// definido en pascal.cpp

extern	int	error;		// definido en pascal.cpp

extern  char	**lines;
extern  int     debug;

#define I_START 0
#define I_RESET 1
#define I_RUN   2
#define I_STEP  3
#define I_LINE  4

int	interprete( int icmd, int valor );

void		yyerror( char * m ); // error sintactico
void		errorsemantico( char * m, TAtInfo & stk);
void		errorsemantico( char * m, int linea);
void		errorejecucion( char * m, int linea );


void     imprime( char *, ... );
