//---------------------------------------------------------------------------

#include <vcl.h>
#include <StrUtils.hpp>
#include <process.h>
#pragma hdrstop

#include "Bienvenida.h"
#include "Algoritmo.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm5 *Form5;
bool Estado=true;
//---------------------------------------------------------------------------
__fastcall TForm5::TForm5(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm5::Button1Click(TObject *Sender)
{
        this->Close();
}
//---------------------------------------------------------------------------


void __fastcall TForm5::Timer1Timer(TObject *Sender)
{
        if(Estado==true)
        {
         Sleep(1000);
         Estado=false;
         Form1->Show();
        }
        else
        {
           this->Hide();
          //exit(1);
        }



}
//---------------------------------------------------------------------------






void __fastcall TForm5::Timer2Timer(TObject *Sender)
{
//       this->Label1->Caption=MidStr( this->Label1->Caption,2,this->Label1->Caption.Length())+ LeftStr( this->Label1->Caption,1);
            
}
//---------------------------------------------------------------------------

