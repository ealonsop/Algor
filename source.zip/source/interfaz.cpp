//---------------------------------------------------------------------------


#pragma hdrstop

#include <vcl.h>
#pragma hdrstop

#include "interfaz.h"
#include "Algoritmo.h"
//#include "VentanaImprimir.h"

//---------------------------------------------------------------------------

#pragma package(smart_init)

void    es_imprimir( char * texto )
{
  AnsiString A, L;


  A = texto;
     int total;
     total = Form1->RichEdit1->Lines->Count;
     if ( total == 0 )
        Form1->RichEdit1->Lines->Append(A);
     else
     {
       L = Form1->RichEdit1->Lines->Strings[total-1];
       for ( int j = 1; j <= A.Length(); j++ )
       {
         if ( A[j] == '\n' ) {
            Form1->RichEdit1->Lines->Strings[total-1] = L;
            L = "";
            Form1->RichEdit1->Lines->Append(L);
            total++;
         }
         else
            L = L + A[j];
       }
       Form1->RichEdit1->Lines->Strings[total-1] = L;
     }
}

void    es_limpiar()
{
  Form1->RichEdit1->Lines->Clear();
}

int     es_leer(char * dst )
{
  AnsiString NS;
  int r;
  NS = "";
//  Form3->Show();
  if ( InputQuery("SARPer�", "Ingrese valor", NS) == true )
     r = 1;
  else
     r = 0;
  strcpy(dst,NS.c_str());
  return r;
}

//desarrollado el Sabado 16 de julio del 2005
//Limpiar ventana Vars
void va_limpiar()
{
     for(int i=1;i<=Form1->Vars->RowCount;i++)
        for(int j=0;j<=Form1->Vars->ColCount;j++)
           Form1->Vars->Cells[j][i]="";
    Form1->Vars->RowCount=2;
    Form1->PasoFila=1;
}
//desarrollado el Sabado 16 de julio del 2005
//Funcion que adiciona variable con su respectivo valor, ala ventana Vars
void va_adicionar(char *NomVar,char *ValVar)
{
     int pos;
     AnsiString V1(NomVar), V2(ValVar);
     Form1->Vars->Cells[0][Form1->Vars->RowCount-1]=V1;
     Form1->Vars->Cells[1][Form1->Vars->RowCount-1]=V2;

//     if (Form1->Vars->Cells[0][Form1->Vars->RowCount].Trim()!="" && Form1->Vars->Cells[1][Form1->Vars->RowCount].Trim()!="")
         Form1->Vars->RowCount+=1;
//     Form1->Vars->TopRow= Form1->Vars->RowCount-1;
}

/*
Funcion que nos permite seleccionar una linea y lo pinta
*/
void ej_seleccion(int LineaInterprete)
{

         int Linea=LineaInterprete;
         long ind_car;
         long lon_lin;

         if ( LineaInterprete < 1 )
             Form1->m_Documento->SelLength= 0;
         else {
               //Obtenemos el numero de caracter del texto de esa linea
               ind_car=SendMessage(Form1->m_Documento->Handle, EM_LINEINDEX  ,Linea-1,0);
               //Obtenemos la longitud de esa linea de texto
               lon_lin=SendMessage(Form1->m_Documento->Handle, EM_LINELENGTH  ,ind_car,0);
               //::SendMessage(Form1->m_Documento->Handle, EM_SETSEL  ,ind_car,lon_lin);
               Form1->m_Documento->SelStart =ind_car;
               Form1->m_Documento->SelLength=lon_lin;
               Form1->SelStart  = ind_car;
               Form1->SelLength = lon_lin;
               //Nos permite desplazarnos segun avanzamos linea a linea en el editor
               SetScrollPos(Form1->m_Documento->Handle,SB_VERT	,ind_car,true);
         }
}
