/*
   Modulo             : TablaDeSimbolos.h
   Autor              : Jose Secundino Alvites Rodas
   Fecha Creacion     : Lunes 14 de Marzo del 2005
   Fecha Actualizacion: Marte 26 de Abril del 2005
   Pais               : Per�
   Asesor             : Ing. Eduardo Alonso P�rez
*/
#define MAX                  1024
#define MAXTABLA             256
#define MAXNUMARG            256
#define MAXTAMNOMBRE         256
#define DIM_VECTOR           256

struct Tabla_Simbolos
{
      int  Indice;
      char Identificador[MAXTAMNOMBRE]; //Nombre del identificador
      long Direccion_Memoria;
      int  Tipo_Dato;  //Tipo de dato de la variable:
      int  Tipo_Simbolo; //TIPO_VARIABLE, TIPO_FUNCION,etc.
      unsigned char Valor;
      int  Comienzo_Codigo;//Cuando se trata de funciones
      int  Tipo_Base; //Almacena el tipo base si se trata de una variable tipo matriz
      char Nombre_Argumentos[MAXNUMARG][MAXTAMNOMBRE];//Nombre de los argumentos para las funciones
      int  Tipo_Parametros_Funcion[MAXNUMARG]; //Tipo de los argumentos para las funciones
      int  Ambito; //El �mbito se define como la parte del programa donde el s�mbolo tiene validez.
      int  Tamano_Maximo;
      int  Valor_Maximo_Dimension; //Numero de dimensiones de una matriz
      int  Numero_Dimensiones[DIM_VECTOR];//Nro. de elementos para cada dimension, si se trata de un matriz
      int  Numero_Parametros;//Nro. de parametros para una funci�n
      int  Numero_Linea_Variable_Declarada;
      int  Numero_Linea_Referencia_Variable;
      int  Valor_Posicion_Codigo_Intermedio;
      int  Posicion;
      int  Cantidad_Entradas;

};

//Inserta un simbolo en la TS, se le puede pasar directamente una estructura de tipo
//s�mbolo o bien la podmos implementar pas�ndole toda la informaci�n del s�mbolo para que ella lo cree.
void Insertar_Simbolo(...);

//Se le pasa el nombre del s�mbolo a buscar y el �mbito y lo devuelve.
//Si el s�mbolo no existe devolver�a un s�mbolo vac�o o una indicaci�n de error.
void Buscar_Simbolo(...);

void Borrar_Simbolo(...);

//Imprime la TS
void Imprimir_Tabla_Simbolos(void);




