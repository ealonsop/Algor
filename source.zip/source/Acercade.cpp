/*
Universidad       : Catolica Santo Toribio De Mogrobejo
Autor             : Jose Secundino Alvites Rodas
Email             : josealvites@hotmail.com;jose_alvitesrodas@yahoo.com.mx
Fecha creaci�n    : Lunes,21 de Marzo del 2005
Fecha modificacion:
Pais              : Peru-Lambayeque-Chaiclayo-Reque
Asesor            : Ing. Eduardo Alonso Perez 
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Acercade.h"
#include <windows.h>

#define DIV 1024

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm4 *Form4;
//---------------------------------------------------------------------------
__fastcall TForm4::TForm4(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm4::FormCreate(TObject *Sender)
{
       MEMORYSTATUSEX memoria;
       memoria.dwLength=sizeof(memoria);
       ::GlobalMemoryStatusEx(&memoria);
       OSVERSIONINFO Version;
       SYSTEM_INFO   Sistema;
       ::ZeroMemory(&Version, sizeof(OSVERSIONINFOEX));
       Version.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
       AnsiString Alvites="Versi�n 1.0 \nCopyright 2005\n";
                  Alvites+="Pocentaje de memoria usada: ";
                  Alvites+= memoria.dwMemoryLoad;
                  Alvites+=" Kb\nTotal bytes de memoria fisica: ";
                  Alvites+=memoria.ullTotalPhys/DIV;
                  Alvites+=" Kb\nTotal bytes p�gina de archivo: ";
                  Alvites+=memoria.ullTotalPageFile/DIV;
                  Alvites+=" Kb\nTotal bytes de memoria virtual: ";
                  Alvites+=memoria.ullTotalVirtual/DIV;
                  Alvites+=" Kb\nTotal bytes espacio de memoria virtual: ";
                  Alvites+=memoria.ullAvailVirtual/DIV;
                  Alvites+=" Kb\nTotal bytes espacio de memoria extendida: ";
                  Alvites+=memoria.ullAvailExtendedVirtual/DIV;
                  Alvites+=" Kb\n";

       DWORD SectorsPerCluster,BytesPerSector,NumberOfFreeClusters,TotalNumberOfClusters;
       char *miuni[]={"A:/","B:/","C:/","D:/","E:/","F:/","G:/","H:/","I:/",
                      "J:/","K:/","L:/","M:/","N:/","O:/","P:/","Q:/","R:/",
                      "S:/","T:/","U:/","V:/","W:/","X:/","Y:/","Z:/"};
       //::GetLogicalDrives()
       AnsiString Unidad=IntToStr(::GetLogicalDrives());
       ::GetDiskFreeSpace((LPCSTR)miuni[Unidad.SubString(1,1).ToInt()],&SectorsPerCluster,&BytesPerSector,&NumberOfFreeClusters,&TotalNumberOfClusters);
                  Alvites+="Espacio total unidad: ";
                  Alvites+= SectorsPerCluster*BytesPerSector*TotalNumberOfClusters;
                  Alvites+="\nEspacio libre unidad: ";
                  Alvites+= SectorsPerCluster*BytesPerSector*NumberOfFreeClusters;
       Version.dwOSVersionInfoSize=sizeof(OSVERSIONINFOEX);
       ::GetVersionEx(&Version);
       switch(Version.dwPlatformId)
       {
              case VER_PLATFORM_WIN32s:
                   Alvites+="\nWindows 3.1";
                   break;
              case VER_PLATFORM_WIN32_WINDOWS:
                   if(Version.dwMajorVersion == 4 && Version.dwMinorVersion )
                      Alvites+="\nVersion Windows 95";
                   if(Version.dwMajorVersion == 4 && Version.dwMinorVersion == 10)
                      Alvites+="\nVersion Windows 98";
                   if(Version.dwMajorVersion == 4 && Version.dwMinorVersion == 90)
                      Alvites+="\nMicrosoft Windows Millennium Edition";   
                   break;
              case VER_PLATFORM_WIN32_NT:
                   if ( Version.dwMajorVersion == 5 && Version.dwMinorVersion == 2 )
                        Alvites+="\nMicrosoft Windows Server Family";
                   if ( Version.dwMajorVersion == 5 && Version.dwMinorVersion == 1 )
                        Alvites+="\nMicrosoft Windows XP";
                   if ( Version.dwMajorVersion == 5 && Version.dwMinorVersion == 0 )
                        Alvites+="\nMicrosoft Windows 2000";
                   
       }
       ::GetSystemInfo(&Sistema);
       switch(Sistema.dwProcessorType)
       {      case PROCESSOR_INTEL_386:
                   Alvites+="\nProcesador Intel 386 o compatible";
                   break;
              case PROCESSOR_INTEL_486:
                   Alvites+="\nProcesador Intel 486 o compatible";
                   break;
              case PROCESSOR_INTEL_PENTIUM:
                   Alvites+="\nProcesador Intel Pentium o compatible";
                   break;
              case PROCESSOR_MIPS_R4000:
                   Alvites+="\nProcesador MIPS R4000";
                   break;
              case PROCESSOR_ALPHA_21064:
                   Alvites+="\nProcesador DFC ALPHA 21064";
                   break;
       }
       this->Label1->Caption=Alvites;

}
//---------------------------------------------------------------------------

