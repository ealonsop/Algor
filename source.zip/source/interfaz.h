#include <vcl.h>
//---------------------------------------------------------------------------

#ifndef interfazH
#define interfazH
//---------------------------------------------------------------------------

extern  int yylineE;
extern  int error;
void    es_imprimir( char * texto );
void    es_limpiar();
void    va_limpiar();
void    va_adicionar(char * NomVar,char * ValVar);
void    ej_seleccion(int LineaInterprete);
int     es_leer(char * dst );
int     compilador(char * archivo, int icmd, int valor );
#endif
