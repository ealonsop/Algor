/* Autor          : Jose Secundino Alvites Rodas
*  Fecha Creaci�n : Reque, Febrero del 2005
*  Pais           : Peru
*  Email          : josealvites@hotmail.com
*  Asesor         : Ing. Eduardo Alonso P�rez
*/
//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Algoritmo.h"
#include <Printers.hpp>
#include <Registry.hpp>
#include "Estructura_Selectiva.h"
#include "Acercade.h"
#include "TablaDeSimbolos.h"
#include "globales.h"

//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

void   cambiaEstado( int est )
{
  Form1->estadoI = est;
  if ( Form1->estadoI == 0 )
  {
    SendMessage(Form1->m_Documento->Handle,EM_SETREADONLY,false,0);
    SendMessage(Form1->ToolBar1->Handle,TB_ENABLEBUTTON,5,(LPARAM) MAKELONG(false,0));//Boton Terminar
    Form1->Terminar1->Enabled = false;   // Terminar Mnu

  }
  else
  {
    SendMessage(Form1->m_Documento->Handle,EM_SETREADONLY,true,0);
    SendMessage(Form1->ToolBar1->Handle,TB_ENABLEBUTTON,5,(LPARAM) MAKELONG(true,0));//Boton Terminar
    Form1->Terminar1->Enabled = true;
  }

}
static int Compila()
{
   char * s;
   AnsiString A;

   A = ExtractFilePath(Application->ExeName) + "algor.tmp";
   s = A.c_str();
   Form1->m_Documento->Lines->
           SaveToFile(A);
         es_limpiar();
//         Form3->Show();
         compilador(s,I_START,0);
         if (error)
             ej_seleccion(yylineE);
   return error;
}
//---------------------------------------------------------------------------
//Funci�n abrir archivo
void Abrir_Archivo(){

     va_limpiar();
     //Filtramos todos los archivos texto
     Form1->OpenDialog1->Filter = "Archivo texto (*.txt)|*.TXT";
     //Presentamos cuadro de dialogo abrir archivo
     if (Form1->OpenDialog1->Execute()){
        Form1->m_Documento->Lines->LoadFromFile(Form1->OpenDialog1->FileName);
        Form1->Caption=ExtractFileName(Form1->OpenDialog1->FileName);
     }
}
//----------------------------------------------------------------------------
//Guardar archivo
void Guardar_Archivo()
{
  va_limpiar();
  //int iFileHandle;
  AnsiString Cadena="";
  Form1->SaveDialog1->Filter = "Archivo texto (*.txt)|*.TXT";
  if(Form1->SaveDialog1->Execute()){
     Form1->m_Documento->Lines->SaveToFile(Form1->SaveDialog1->FileName);
     Form1->Caption=ExtractFileName(Form1->SaveDialog1->FileName);
  }
}
//----------------------------------------------------------------------------
//Nuevo archivo
void Nuevo_Archivo()
{
     va_limpiar();
     Form1->m_Documento->Clear();
     Form1->m_Documento->SetFocus();
     Form1->Caption="SARPer�";
}
//----------------------------------------------------------------------------
//Ir a linea
void Ir_a(int Linea)
{
     if (Linea>SendMessage(Form1->m_Documento->Handle, EM_GETLINECOUNT,0,0))
         Application->MessageBox("Nro. linea no se encuentra", "Ir a..", IDOK);
         else
            {
              long ind_car;
              ind_car=SendMessage(Form1->m_Documento->Handle, EM_LINEINDEX  ,Linea-1,0);
              Form1->m_Documento->SelStart=ind_car;
              Form1->m_Documento->SelLength=0;
              Form1->StatusBar1->Panels->Items[0]->Text=Linea;
              Form1->m_Documento->Perform(EM_SCROLLCARET, 0, 0);
              Form1->m_Documento->SetFocus();
            }
}

//---------------------------------------------------------------------------
//Buscar palabra en el editor de texto
void Buscar_Palabra(AnsiString Palabra)
{
     bool Enc=false;
     int Long_Pal =Palabra.Length();//Longitud palabra a buscar
     int Long_Docu=Form1->m_Documento->Text.Length();//Longitu texto editor
     for(int i=0;i<=Long_Docu;i++)
     {
         AnsiString xPalabra="";
         xPalabra=Form1->m_Documento->Text.SubString(i,Long_Pal);
         if(Palabra==xPalabra)
         {
            Form1->m_Documento->SelStart=i-1;
            Form1->m_Documento->SelLength=Long_Pal;
            Form1->m_Documento->SelAttributes->Color=clRed;
            Enc=true;
            //break;
         }
     }
     if(Enc==false)
       Application->MessageBox("Palabra no existe", "Buscar palabra", IDOK);
           
}
//----------------------------------------------------------------------------
//Valida si es numero
bool Numero(AnsiString Cad)
{
     bool Rpta=true;
     char *Car=Cad.c_str();
     for(int i=0;i<=Cad.Length()-1;i++)
     {
         if (!(isdigit((char)Car[i])))
             Rpta=false;
     }
     return Rpta;
}
//---------------------------------------------------------------------------
//Salir aplicacion
void Salir_Aplicacion()
{
     int Longitud_Doc=0;
       Longitud_Doc=Form1->m_Documento->Text.Trim().Length();
       switch (Longitud_Doc)
       {
             case 0:
                    Application->Terminate();
                    break;
             default:
                   int Rpta=Application->MessageBox("Desea guardar?","SARPeru",MB_YESNOCANCEL);
                   switch (Rpta)
                   {
                         case 6:
                              Guardar_Archivo();
                              break;
                         case 7:
                              Application->Terminate();
                              break;
                         default:
                              Form1->m_Documento->SetFocus();
                              break;
                   }
                   break;
       }
}
//---------------------------------------------------------------------------
//Nuevo
void Nuevo()
{
       int Longitud_Doc=0;
       Longitud_Doc=Form1->m_Documento->Text.Trim().Length();
       switch (Longitud_Doc)
       {
             case 0:
                   Nuevo_Archivo();
                   break;
             default:
                   int Rpta=Application->MessageBox("Desea guardar?","SARPeru",MB_YESNOCANCEL+MB_ICONINFORMATION);
                   switch (Rpta)
                   {
                         case 6:
                              Guardar_Archivo();
                              break;
                         case 7:
                              Nuevo_Archivo();
                              break;
                         default:
                              Form1->m_Documento->SetFocus();
                              break;
                   }
                   break;
       }
}
//---------------------------------------------------------------------------
//Abrir
void Abrir()
{
       int Longitud_Doc=0;
       Longitud_Doc=Form1->m_Documento->Text.Trim().Length();
       switch (Longitud_Doc)
       {
             case 0:
                   Abrir_Archivo();
                   break;
             default:
                   int Rpta=Application->MessageBox("Desea guardar?","SARPeru",MB_YESNOCANCEL+MB_ICONINFORMATION);
                   switch (Rpta)
                   {
                         case 6:
                              Guardar_Archivo();
                              break;
                         case 7:
                              Abrir_Archivo();
                              break;
                         default:
                              Form1->m_Documento->SetFocus();
                              break;
                   }
                   break;
       }
}
//---------------------------------------------------------------------------
//Guardar
void Guardar()
{
     int Longitud_Doc=0;
       Longitud_Doc=Form1->m_Documento->Text.Trim().Length();
       if (Longitud_Doc>0)
           Guardar_Archivo();
         else
            Application->MessageBox("Documento vacio","SARPeru",MB_OK+MB_ICONEXCLAMATION);

}
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
        this->m_Documento->WantTabs=true;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::m_DocumentoChange(TObject *Sender)
{
       StatusBar1->Panels->Items[0]->Text=this->m_Documento->CaretPos.y+1;
       StatusBar1->Panels->Items[1]->Text=this->m_Documento->CaretPos.x+1;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::m_DocumentoKeyUp(TObject *Sender, WORD &Key,
      TShiftState Shift)
{
     if ( estadoI == 1 )
     {
         Form1->m_Documento->SelStart = Form1->SelStart;
         Form1->m_Documento->SelLength = Form1->SelLength;
     }

     StatusBar1->Panels->Items[0]->Text=m_Documento->CaretPos.y+1;
     StatusBar1->Panels->Items[1]->Text=m_Documento->CaretPos.x+1;
     if (m_Documento->SelLength>0 && this->m_Documento->Text.Trim()!="")
           StatusBar1->Panels->Items[2]->Text=m_Documento->SelLength;
           else
               StatusBar1->Panels->Items[2]->Text="";
     if(Key==13)
        this->m_Documento->Paragraph->Numbering =nsNone;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Abrir1Click(TObject *Sender)
{
       Abrir();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton2Click(TObject *Sender)
{
       Abrir();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Guardar1Click(TObject *Sender)
{
      Guardar();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton3Click(TObject *Sender)
{
       Guardar();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Seleccionartodo1Click(TObject *Sender)
{
       if(SendMessage(this->m_Documento->Handle,EM_SETSEL,0,this->m_Documento->Text.Trim().Length())==0)
          MessageBox(this->m_Documento->Handle,"No hay texto para seleccionar","SARPeru",MB_ICONEXCLAMATION);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Copiar1Click(TObject *Sender)
{
       SendMessage(this->m_Documento->Handle,WM_COPY,0,0);        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Pegar1Click(TObject *Sender)
{
       SendMessage(this->m_Documento->Handle,WM_PASTE,0,0); 
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Cortar1Click(TObject *Sender)
{
        SendMessage(this->m_Documento->Handle,WM_CUT,0,0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Eliminar1Click(TObject *Sender)
{
       SendMessage(this->m_Documento->Handle,WM_CLEAR,0,0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Buscar1Click(TObject *Sender)
{
     /* AnsiString Palabra = InputBox("Buscar palabra", "Ingrese palabra a buscar:", "");
       if(!Palabra.IsEmpty())//Verifica si palabra contiene espacio en blanco
          Buscar_Palabra(Palabra);
          else
              ShowMessage("Ingrese palabra");*/
       FindDialog1->Execute();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Ira1Click(TObject *Sender)
{
       int xLinea=m_Documento->CaretPos.y+1;
       AnsiString InputString = InputBox("Ir a...", "Ingrese n�mero de l�nea:", xLinea);
       if(Numero(InputString.Trim())==true)
       {
          xLinea=InputString.ToInt();
          if(m_Documento->Text.Trim().Length()==0)
             Application->MessageBox("Editor de texto vacio", "Ir a...",MB_ICONEXCLAMATION);
             else
                 Ir_a(xLinea);
        }
        else
             Application->MessageBox("Ingrese solo numeros", "Ir a...",MB_ICONWARNING);        
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Nuevo1Click(TObject *Sender)
{
       Nuevo();        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton1Click(TObject *Sender)
{
         Nuevo();         
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Salir1Click(TObject *Sender)
{
       Salir_Aplicacion();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Fuente1Click(TObject *Sender)
{
       FontDialog1->Options.Clear();
       //Determina la apriencia del dialogo
       FontDialog1->Options << fdNoStyleSel;
       //Visualiza el dialogo de la fuente del sistema
       FontDialog1->Execute();
       //Copia las propiedades de FontDialog1 a m_Documento
       this->m_Documento->Font->Assign(FontDialog1->Font);        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
       Salir_Aplicacion();
       TRegistry *Registro = new TRegistry;
       Registro->RootKey = HKEY_CURRENT_USER;
       Registro->OpenKey("JoseSecundinoAlvitesRodas", true);
       Registro->WriteInteger("Left", Left);
       Registro->WriteInteger("Top", Top);
       Registro->CloseKey();

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Deshacer1Click(TObject *Sender)
{
       SendMessage(this->m_Documento->Handle,WM_CLEAR,0,0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Rea1Click(TObject *Sender)
{
       SendMessage(this->m_Documento->Handle,WM_UNDO,0,0);     
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Reemplazar1Click(TObject *Sender)
{
        ReplaceDialog1->Execute();                
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ReplaceDialog1Replace(TObject *Sender)
{
       if (ReplaceDialog1->Options.Contains(frReplaceAll))
       {
           for(int i=1;i<this->m_Documento->Text.Length();i++)
           {
              int SelPos = this->m_Documento->Lines->Text.Pos(ReplaceDialog1->FindText.Trim());
              if (SelPos>0)
              {
                  this->m_Documento->SelStart = SelPos - 1;
                  this->m_Documento->SelLength = ReplaceDialog1->FindText.Length();
                  this->m_Documento->SelAttributes->Color=clFuchsia;
                  this->m_Documento->SelText = ReplaceDialog1->ReplaceText;
                  m_Documento->Perform(EM_SCROLLCARET, 0, 0);
              }
              else
                 {
                   Application->MessageBox("Reemplazar palabra","Palabra no existe",MB_OK);
                   ReplaceDialog1->CloseDialog();
                   break;
                  }


           }
       }
       else
       {
               int SelPos = this->m_Documento->Lines->Text.Pos(ReplaceDialog1->FindText.Trim());
               if (SelPos>0)
               {
                   this->m_Documento->SelStart = SelPos - 1;
                   this->m_Documento->SelLength = ReplaceDialog1->FindText.Length();
                   this->m_Documento->SelAttributes->Color=clFuchsia;
                   this->m_Documento->SelText = ReplaceDialog1->ReplaceText;
                   m_Documento->Perform(EM_SCROLLCARET, 0, 0);

               }
                else
                    {
                      Application->MessageBox("Reemplazar palabra","Palabra no existe",MB_OK);
                      ReplaceDialog1->CloseDialog();
                    }
      }
       
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Imprimir1Click(TObject *Sender)
{
        if (m_Documento->Text.Trim().Length()>0){
           if (PrintDialog1->Execute()){
               try {
                     m_Documento->Print(this->Caption);
               }
               catch(...){
                           Printer()->EndDoc();
                           throw;
               }
            }
        }
        else
            ShowMessage("Documento en blanco");    
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Configurarinpresora1Click(TObject *Sender)
{
         PrinterSetupDialog1->Execute();         
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Deshacer2Click(TObject *Sender)
{
       Deshacer1Click(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Rehacer1Click(TObject *Sender)
{
        Rea1Click(Sender);         
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Cortar2Click(TObject *Sender)
{
       Cortar1Click(Sender);       
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Copiar2Click(TObject *Sender)
{
       Copiar1Click(Sender);      
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Pegar2Click(TObject *Sender)
{
      Pegar1Click(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Eliminar2Click(TObject *Sender)
{
      Eliminar1Click(Sender);          
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Seleccionartodo2Click(TObject *Sender)
{
       Seleccionartodo1Click(Sender);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::m_DocumentoMouseUp(TObject *Sender,
      TMouseButton Button, TShiftState Shift, int X, int Y)
{
      if(!(m_Documento->SelLength>0))
       {
          StatusBar1->Panels->Items[0]->Text=m_Documento->CaretPos.y+1;
          StatusBar1->Panels->Items[1]->Text=m_Documento->CaretPos.x+1;
          StatusBar1->Panels->Items[2]->Text="";
       }
       else if (m_Documento->SelLength>0 && m_Documento->Text.Trim()!="" )
           StatusBar1->Panels->Items[2]->Text=m_Documento->SelLength;

}
//---------------------------------------------------------------------------

void __fastcall TForm1::FindDialog1Find(TObject *Sender)
{
        int Encontrado, Inicio, Fin;
        if (m_Documento->SelLength)
            Inicio = m_Documento->SelStart + m_Documento->SelLength;
            else
                Inicio = 0;

        Fin = m_Documento->Text.Length() - Inicio;
        if (FindDialog1->Options.Contains(frWholeWord))
        {
            Encontrado = m_Documento->FindText(FindDialog1->FindText.Trim(), Inicio, Fin, TSearchTypes()<< stWholeWord);
            if (Encontrado > -1)
            {
                m_Documento->SetFocus();
                this->m_Documento->SelAttributes->Color=clFuchsia;
                m_Documento->SelStart = Encontrado;
                m_Documento->SelLength = FindDialog1->FindText.Length();
                m_Documento->Perform(EM_SCROLLCARET, 0, 0);
            }
            else
            {
                ShowMessage("Palabra no existe");
                FindDialog1->CloseDialog();
            }
        }

        if (FindDialog1->Options.Contains(frMatchCase))
        {
            Encontrado = m_Documento->FindText(FindDialog1->FindText.Trim(), Inicio, Fin, TSearchTypes()<< stMatchCase);
            if (Encontrado > -1)
            {
                m_Documento->SetFocus();
                this->m_Documento->SelAttributes->Color=clFuchsia;
                m_Documento->SelStart = Encontrado;
                m_Documento->SelLength = FindDialog1->FindText.Length();
                m_Documento->Perform(EM_SCROLLCARET, 0, 0);
            }
            else
            {
                ShowMessage("Palabra no existe");
                FindDialog1->CloseDialog();
            }
        }

}
//---------------------------------------------------------------------------


void __fastcall TForm1::ToolButton8Click(TObject *Sender)
{
       if (this->m_Documento->Paragraph->Numbering == nsBullet)
       {
         this->m_Documento->Paragraph->Numbering =nsNone;
         PtosInter[this->m_Documento->CaretPos.y]=0;
       }
        else
           {
             this->m_Documento->Paragraph->Numbering =nsBullet;
             PtosInter[this->m_Documento->CaretPos.y]=this->m_Documento->CaretPos.y+1;
           }
}
//---------------------------------------------------------------------------



void __fastcall TForm1::Estructuras1Click(TObject *Sender)
{
       Form2->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton4Click(TObject *Sender)
{

       char * s;
       AnsiString A;

       if ( estadoI == 0 )
       {
         Compila();
         if (!error)
         {
            cambiaEstado(1);
            compilador(NULL,I_RUN,0);
            // falta ver si se detuvo x pto de interrup.
            cambiaEstado(0);
         }
         else{
              //Mostramos la linea de error en la barra de estado
              this->StatusBar1->Panels->Items[0]->Text=yylineE;
         }

       }
       else {
            compilador(NULL,I_RUN,0);
            // falta ver si se detuvo x pto de interrup.
            cambiaEstado(0);
         }

}
//---------------------------------------------------------------------------



void __fastcall TForm1::FormCreate(TObject *Sender)
{
/*       TRegistry *Registro=new TRegistry;
       Registro->RootKey=HKEY_CURRENT_USER;
       Registro->OpenKey("JoseSecundinoAlvitesRodas", true);
       Left = Registro->ReadInteger("Left");
       Top  = Registro->ReadInteger("Top");
       Registro->CloseKey();
*/
       SendMessage(this->m_Documento->Handle, EM_SETMARGINS  ,EC_LEFTMARGIN,10);
       Vars->Cells[0][0]="Nombre";
       Vars->Cells[1][0]="Valor";
       this->Vars->ColWidths[0]=300;
       this->Vars->ColWidths[1]=400;
       this->Vars->RowCount = 2;
       Form1->m_Documento->HideSelection = false;
       cambiaEstado(0);
       PasoFila=1;
       

}
//---------------------------------------------------------------------------

void __fastcall TForm1::Acercade1Click(TObject *Sender)
{
       Form4->ShowModal();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton9Click(TObject *Sender)
{
 if ( RichEdit1->Visible )
 {
    RichEdit1->Hide();
    this->Splitter2->Hide();
 }
 else
 {
    RichEdit1->Show();
    this->Splitter2->Show();
 }

/*  if ( Form3->Visible )
      Form3->Hide();
  else {
      Form3->Show();
  }
*/
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton10Click(TObject *Sender)
{

  if ( Vars->Visible ){
          this->Vars->Hide();
          this->Splitter1->Hide();
  }
  else{
     
     this->Vars->Show();
     this->Splitter1->Show();
  }
}
//---------------------------------------------------------------------------
   
void __fastcall TForm1::Iniciar1Click(TObject *Sender)
{
  ToolButton4Click(Sender);
}
//---------------------------------------------------------------------------



void __fastcall TForm1::ToolButton11Click(TObject *Sender)
{
        AnsiString Estructura;
        Estructura="\nSi\t\tEntonces\n\n\  Sino\n\nFinSi";

        AnsiString TextoLin="";
        TextoLin=Form1->m_Documento->Lines->Strings[m_Documento->CaretPos.y].Trim();
        if (!(TextoLin==""))
           ShowMessage("Seleccione linea en blanco");
         else
             Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[m_Documento->CaretPos.y].Insert(Estructura.Trim(),0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton12Click(TObject *Sender)
{
       AnsiString Estructura;
       Estructura="\nMientras\t\tHacer\n\nFinMientras"; 

        AnsiString TextoLin="";
        TextoLin=Form1->m_Documento->Lines->Strings[m_Documento->CaretPos.y].Trim();
        if (!(TextoLin==""))
           ShowMessage("Seleccione linea en blanco");
         else
             Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[m_Documento->CaretPos.y].Insert(Estructura.Trim(),0);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton13Click(TObject *Sender)
{
       AnsiString Estructura;
       Estructura="\nPara\t\tHasta\t\tHacer\n\nFinPara";

        AnsiString TextoLin="";
        TextoLin=Form1->m_Documento->Lines->Strings[m_Documento->CaretPos.y].Trim();
        if (!(TextoLin==""))
           ShowMessage("Seleccione linea en blanco");
         else
             Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[m_Documento->CaretPos.y].Insert(Estructura.Trim(),0);
        
}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton15Click(TObject *Sender)
{
       if ( estadoI == 0 )
       {
           Compila();
           Show();
           if (!error)
           {
               cambiaEstado(1);
           }
            else
               this->StatusBar1->Panels->Items[0]->Text=yylineE;
       }
       if ( estadoI == 1 ){
           if ( compilador(NULL,I_STEP,0) == 0 )
           {
               cambiaEstado(0);
               if ( !error )
               {
                   ej_seleccion(-1);
               }
                else
                     this->StatusBar1->Panels->Items[0]->Text=yylineE;
           }
       }

}
//---------------------------------------------------------------------------

void __fastcall TForm1::ToolButton16Click(TObject *Sender)
{
     int linea;
     if ( estadoI == 0 )
       {
         Compila();
         if (!error)
         {
            cambiaEstado(1);
            linea =  m_Documento->CaretPos.y+1;
            if ( compilador(NULL,I_LINE,linea) == 0 )
           {
               cambiaEstado(0);
               if ( !error )
                   ej_seleccion(-1);
                 else
                     this->StatusBar1->Panels->Items[0]->Text=yylineE;
           }
         }
         else
             this->StatusBar1->Panels->Items[0]->Text=yylineE;
       }
       else {
            linea =  m_Documento->CaretPos.y+1;
            if ( compilador(NULL,I_LINE,linea) == 0 )
            {
               cambiaEstado(0);
               if ( !error )
                   ej_seleccion(-1);
                 else
                     this->StatusBar1->Panels->Items[0]->Text=yylineE;
            }
       }
}
//---------------------------------------------------------------------------




void __fastcall TForm1::Ejecutarhastaelcursor2Click(TObject *Sender)
{
 ToolButton15Click(Sender);
}

//---------------------------------------------------------------------------

void __fastcall TForm1::Ejecutarhastaelcursor3Click(TObject *Sender)
{
 ToolButton16Click(Sender);
}
//---------------------------------------------------------------------------



void __fastcall TForm1::ToolButton6Click(TObject *Sender)
{
  if ( estadoI == 1 )
  {
    compilador(NULL,I_RESET,0);
    cambiaEstado(0);
    if ( !error )
       ej_seleccion(-1);
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Terminar1Click(TObject *Sender)
{
  ToolButton6Click(Sender);        
}
//---------------------------------------------------------------------------



void __fastcall TForm1::BloqueconcomentariosClick(TObject *Sender)
{
       AnsiString Cad="";
       Cad=this->m_Documento->Lines->Strings[this->m_Documento->CaretPos.y];
       int Fila=this->m_Documento->CaretPos.y;
       this->m_Documento->Lines->Strings[Fila]="";
       this->m_Documento->Lines->Strings[Fila]=";"+Cad;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::BloquesincomentariosClick(TObject *Sender)
{
       int        ocu   =0;
       int        LonCad=0;
       int        Fila  =0;
       AnsiString Cad   ="";

       Fila  =this->m_Documento->CaretPos.y;
       Cad   =this->m_Documento->Lines->Strings[Fila];
       LonCad=this->m_Documento->Lines->Strings[Fila].Length();

       for(int i=0;i<=LonCad;i++)
       {
          if(Cad.SubString(i,1)==";"){
             ocu++;
             break;
          }
       }
       if (ocu==0)
          ::MessageBox(this->Handle,"No hay comentarios, para quitar","SARPeru",16);
         else{
            this->m_Documento->Lines->Strings[Fila].Trim()="";
            this->m_Documento->Lines->Strings[Fila]=Cad.SubString(ocu+1,LonCad);
        }
//       ShowMessage(ocu);

}
//---------------------------------------------------------------------------


