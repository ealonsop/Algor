//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Estructura_Selectiva.h"
#include "Algoritmo.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm2 *Form2;
int Opc;
AnsiString Estructura;
//---------------------------------------------------------------------------
__fastcall TForm2::TForm2(TComponent* Owner)
        : TForm(Owner)
{
}
//---------------------------------------------------------------------------


void __fastcall TForm2::RadioButton1Click(TObject *Sender)
{
       Opc=1;
       Estructura="\nSi\t\tEntoces\n\nFinSi";        
}
//---------------------------------------------------------------------------

void __fastcall TForm2::RadioButton2Click(TObject *Sender)
{
        Opc=2;
        Estructura="\nSi\t\tEntonces\n\n\  Sino\n\nFinSi"; 
}
//---------------------------------------------------------------------------

void __fastcall TForm2::RadioButton3Click(TObject *Sender)
{
       Opc=3;
       Estructura="\nMientras\t\tHacer\n\nFinMientras";        
}
//---------------------------------------------------------------------------

void __fastcall TForm2::RadioButton4Click(TObject *Sender)
{
       Opc=4;
       Estructura="\nRepetir\n\nHasta"; 
}
//---------------------------------------------------------------------------

void __fastcall TForm2::RadioButton5Click(TObject *Sender)
{
       Opc=5;
       Estructura="\nPara\t\tHasta\t\tHacer\n\nFinPara";
}
//---------------------------------------------------------------------------

void __fastcall TForm2::RadioButton6Click(TObject *Sender)
{
       Opc=6;
       Estructura="\nSegun Sea\t\tHacer\n\nFinSegun";        
}
//---------------------------------------------------------------------------

void __fastcall TForm2::Button1Click(TObject *Sender)
{
       int y_linea=Form1->m_Documento->CaretPos.y;

       AnsiString TextoLin="";
       TextoLin=Form1->m_Documento->Lines->Strings[y_linea].Trim();

       if (!(TextoLin==""))
           ShowMessage("Seleccione linea en blanco");
          else{
               switch (Opc)
               {
                      case 1:

                           Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[y_linea].Insert(Estructura.Trim(),0);
                           break;
                      case 2:

                           Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[y_linea].Insert(Estructura.Trim(),0);
                           break;
                      case 3:

                           Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[y_linea].Insert(Estructura.Trim(),0);
                           break;
                      case 4:

                           Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[y_linea].Insert(Estructura.Trim(),0);
                           break;
                      case 5:

                           Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[y_linea].Insert(Estructura.Trim(),0);
                           break;
                      case 6:

                           Form1->m_Documento->SelText=Form1->m_Documento->Lines->Strings[y_linea].Insert(Estructura.Trim(),0);
                           break;

               }
                this->Close();  

          }

}
//---------------------------------------------------------------------------

void __fastcall TForm2::Button2Click(TObject *Sender)
{
       this->Close();         
}
//---------------------------------------------------------------------------


